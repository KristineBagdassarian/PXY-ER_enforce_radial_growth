function[cellType_Xy,cellType_Ph]=assignCellTypesStemsNoFiber(propertiesXylem,propertiesPhloem)
cellTypes={'Xylem' 'Phloem' };
cellType_Xy=repmat(cellTypes(1),size(propertiesXylem(:,1)),1);
cellType_Ph=repmat(cellTypes(2),size(propertiesPhloem(:,1)),1);
