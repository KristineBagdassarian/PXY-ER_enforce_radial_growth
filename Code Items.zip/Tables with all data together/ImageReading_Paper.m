%the code reads images from a folder, then extracts the properties of the
%differently coloured cells based on size and shape
%the extracted data is saved into excell tables

%In the below, WT corresponds to Wild Type


%access the folder with WT images
%apply algorithm to WT images 
%with number of standard deviations for outlier removal as below
sourceWT = 'C:\Users\NBuser\Documents\MATLAB\Images Paper\Coloured Images\WT';
[propertiesXylem_WT,propertiesFiber_WT,propertiesPhloem_WT,propertiesParynchema_WT]=extractCellProperties(sourceWT);

%repeat for other genotypes

sourcepxF = 'C:\Users\NBuser\Documents\MATLAB\Images Paper\Coloured Images\pxF';
[propertiesXylem_pxF,propertiesFiber_pxF,propertiesPhloem_pxF,propertiesParynchema_pxF]=extractCellProperties(sourcepxF);

sourcepxFer = 'C:\Users\NBuser\Documents\MATLAB\Images Paper\Coloured Images\PxFer';
[propertiesXylem_pxFer,propertiesFiber_pxFer,propertiesPhloem_pxFer,propertiesParynchema_pxFer]=extractCellProperties(sourcepxFer);

sourcepxFererl1 = 'C:\Users\NBuser\Documents\MATLAB\Images Paper\Coloured Images\pxFererl1';
[propertiesXylem_pxFererl1,propertiesFiber_pxFererl1,propertiesPhloem_pxFererl1,propertiesParynchema_pxFererl1]=extractCellProperties(sourcepxFererl1);

sourcepxFererl2 = 'C:\Users\NBuser\Documents\MATLAB\Images Paper\Coloured Images\pxFererl2';
[propertiesXylem_pxFererl2,propertiesFiber_pxFererl2,propertiesPhloem_pxFererl2,propertiesParynchema_pxFererl2]=extractCellProperties(sourcepxFererl2);


%note that pxFerF has no distinguishable xylem fibers; i.e. a new function
%needs to be designed
sourcepxFerF = 'C:\Users\NBuser\Documents\MATLAB\Images Paper\Coloured Images\pxFerF';
[propertiesXylem_pxFerF,propertiesPhloem_pxFerF,propertiesParynchema_pxFerF]=extractCellPropertiesNoFiber(sourcepxFerF);


%names of different columns in future tables

CellProperties={'Species' 'CellType' 'CellArea' 'Ratio' 'Perimeter'};

%name species for each matrix
SpeciesWT='WT';
[Species_WT_Xy,Species_WT_Fi,Species_WT_Ph,Species_WT_Pa]=assignSpecies(propertiesXylem_WT,propertiesFiber_WT,propertiesPhloem_WT,propertiesParynchema_WT,SpeciesWT);
SpeciespxF='pxF';
[Species_pxF_Xy,Species_pxF_Fi,Species_pxF_Ph,Species_pxF_Pa]=assignSpecies(propertiesXylem_pxF,propertiesFiber_pxF,propertiesPhloem_pxF,propertiesParynchema_pxF,SpeciespxF);
SpeciespxFer='pxFer';
[Species_pxFer_Xy,Species_pxFer_Fi,Species_pxFer_Ph,Species_pxFer_Pa]=assignSpecies(propertiesXylem_pxFer,propertiesFiber_pxFer,propertiesPhloem_pxFer,propertiesParynchema_pxFer,SpeciespxFer);
SpeciespxFererl1='pxFererl1';
[Species_pxFererl1_Xy,Species_pxFererl1_Fi,Species_pxFererl1_Ph,Species_pxFererl1_Pa]=assignSpecies(propertiesXylem_pxFererl1,propertiesFiber_pxFererl1,propertiesPhloem_pxFererl1,propertiesParynchema_pxFererl1,SpeciespxFererl1);
SpeciespxFererl2='pxFererl2';
[Species_pxFererl2_Xy,Species_pxFererl2_Fi,Species_pxFererl2_Ph,Species_pxFererl2_Pa]=assignSpecies(propertiesXylem_pxFererl2,propertiesFiber_pxFererl2,propertiesPhloem_pxFererl2,propertiesParynchema_pxFererl2,SpeciespxFererl2);

%pxFerF has no Fiber
SpeciespxFerF='pxFerF';
[Species_pxFerF_Xy,Species_pxFerF_Ph,Species_pxFerF_Pa]=assignSpeciesNoFiber(propertiesXylem_pxFerF,propertiesPhloem_pxFerF,propertiesParynchema_pxFerF,SpeciespxFerF);


%assign names to the cell types in WT
[cellType_WT_Xy,cellType_WT_Fi,cellType_WT_Ph,cellType_WT_Pa]=assignCellTypes(propertiesXylem_WT,propertiesFiber_WT,propertiesPhloem_WT,propertiesParynchema_WT);

%assign names to the cell types in pxF
[cellType_pxF_Xy,cellType_pxF_Fi,cellType_pxF_Ph,cellType_pxF_Pa]=assignCellTypes(propertiesXylem_pxF,propertiesFiber_pxF,propertiesPhloem_pxF,propertiesParynchema_pxF);

%assign names to the cell types in pxFer
[cellType_pxFer_Xy,cellType_pxFer_Fi,cellType_pxFer_Ph,cellType_pxFer_Pa]=assignCellTypes(propertiesXylem_pxFer,propertiesFiber_pxFer,propertiesPhloem_pxFer,propertiesParynchema_pxFer);

%assign names to the cell types in pxFererl1
[cellType_pxFererl1_Xy,cellType_pxFererl1_Fi,cellType_pxFererl1_Ph,cellType_pxFererl1_Pa]=assignCellTypes(propertiesXylem_pxFererl1,propertiesFiber_pxFererl1,propertiesPhloem_pxFererl1,propertiesParynchema_pxFererl1);

%assign names to the cell types in pxFererl2
[cellType_pxFererl2_Xy,cellType_pxFererl2_Fi,cellType_pxFererl2_Ph,cellType_pxFererl2_Pa]=assignCellTypes(propertiesXylem_pxFererl2,propertiesFiber_pxFererl2,propertiesPhloem_pxFererl2,propertiesParynchema_pxFererl2);

%assign names to the cell types in pxFerF (it has no fiber)
[cellType_pxFerF_Xy,cellType_pxFerF_Ph,cellType_pxFerF_Pa]=assignCellTypesNoFiber(propertiesXylem_pxFerF,propertiesPhloem_pxFerF,propertiesParynchema_pxFerF);



%create tables with the properties
%add variable names for each
%For WT
WT_Table_Xy = table(Species_WT_Xy, cellType_WT_Xy, propertiesXylem_WT(:,2),propertiesXylem_WT(:,3),propertiesXylem_WT(:,4)); %the name of the rows come after 'RowNames'
WT_Table_Xy.Properties.VariableNames = CellProperties;

WT_Table_Fi = table(Species_WT_Fi, cellType_WT_Fi, propertiesFiber_WT(:,2),propertiesFiber_WT(:,3),propertiesFiber_WT(:,4)); %the name of the rows come after 'RowNames'
WT_Table_Fi.Properties.VariableNames = CellProperties;

WT_Table_Ph = table(Species_WT_Ph, cellType_WT_Ph, propertiesPhloem_WT(:,2),propertiesPhloem_WT(:,3),propertiesPhloem_WT(:,4)); %the name of the rows come after 'RowNames'
WT_Table_Ph.Properties.VariableNames = CellProperties;

WT_Table_Pa = table(Species_WT_Pa, cellType_WT_Pa, propertiesParynchema_WT(:,2),propertiesParynchema_WT(:,3),propertiesParynchema_WT(:,4)); %the name of the rows come after 'RowNames'
WT_Table_Pa.Properties.VariableNames = CellProperties;

%For pxF
pxF_Table_Xy=table(Species_pxF_Xy, cellType_pxF_Xy, propertiesXylem_pxF(:,2),propertiesXylem_pxF(:,3),propertiesXylem_pxF(:,4)); %the name of the rows come after 'RowNames'
pxF_Table_Xy.Properties.VariableNames = CellProperties;

pxF_Table_Fi = table(Species_pxF_Fi, cellType_pxF_Fi, propertiesFiber_pxF(:,2),propertiesFiber_pxF(:,3),propertiesFiber_pxF(:,4)); %the name of the rows come after 'RowNames'
pxF_Table_Fi.Properties.VariableNames = CellProperties;

pxF_Table_Ph = table(Species_pxF_Ph, cellType_pxF_Ph, propertiesPhloem_pxF(:,2),propertiesPhloem_pxF(:,3),propertiesPhloem_pxF(:,4)); %the name of the rows come after 'RowNames'
pxF_Table_Ph.Properties.VariableNames = CellProperties;

pxF_Table_Pa = table(Species_pxF_Pa, cellType_pxF_Pa, propertiesParynchema_pxF(:,2),propertiesParynchema_pxF(:,3),propertiesParynchema_pxF(:,4)); %the name of the rows come after 'RowNames'
pxF_Table_Pa.Properties.VariableNames = CellProperties;

%For pxFer
pxFer_Table_Xy=table(Species_pxFer_Xy, cellType_pxFer_Xy, propertiesXylem_pxFer(:,2),propertiesXylem_pxFer(:,3),propertiesXylem_pxFer(:,4)); %the name of the rows come after 'RowNames'
pxFer_Table_Xy.Properties.VariableNames = CellProperties;

pxFer_Table_Fi = table(Species_pxFer_Fi, cellType_pxFer_Fi, propertiesFiber_pxFer(:,2),propertiesFiber_pxFer(:,3),propertiesFiber_pxFer(:,4)); %the name of the rows come after 'RowNames'
pxFer_Table_Fi.Properties.VariableNames = CellProperties;

pxFer_Table_Ph = table(Species_pxFer_Ph, cellType_pxFer_Ph, propertiesPhloem_pxFer(:,2),propertiesPhloem_pxFer(:,3),propertiesPhloem_pxFer(:,4)); %the name of the rows come after 'RowNames'
pxFer_Table_Ph.Properties.VariableNames = CellProperties;

pxFer_Table_Pa = table(Species_pxFer_Pa, cellType_pxFer_Pa, propertiesParynchema_pxFer(:,2),propertiesParynchema_pxFer(:,3),propertiesParynchema_pxFer(:,4)); %the name of the rows come after 'RowNames'
pxFer_Table_Pa.Properties.VariableNames = CellProperties;

%For pxFererl1
pxFererl1_Table_Xy=table(Species_pxFererl1_Xy, cellType_pxFererl1_Xy, propertiesXylem_pxFererl1(:,2),propertiesXylem_pxFererl1(:,3),propertiesXylem_pxFererl1(:,4)); %the name of the rows come after 'RowNames'
pxFererl1_Table_Xy.Properties.VariableNames = CellProperties;

pxFererl1_Table_Fi = table(Species_pxFererl1_Fi, cellType_pxFererl1_Fi, propertiesFiber_pxFererl1(:,2),propertiesFiber_pxFererl1(:,3),propertiesFiber_pxFererl1(:,4)); %the name of the rows come after 'RowNames'
pxFererl1_Table_Fi.Properties.VariableNames = CellProperties;

pxFererl1_Table_Ph = table(Species_pxFererl1_Ph, cellType_pxFererl1_Ph, propertiesPhloem_pxFererl1(:,2),propertiesPhloem_pxFererl1(:,3),propertiesPhloem_pxFererl1(:,4)); %the name of the rows come after 'RowNames'
pxFererl1_Table_Ph.Properties.VariableNames = CellProperties;

pxFererl1_Table_Pa = table(Species_pxFererl1_Pa, cellType_pxFererl1_Pa, propertiesParynchema_pxFererl1(:,2),propertiesParynchema_pxFererl1(:,3),propertiesParynchema_pxFererl1(:,4)); %the name of the rows come after 'RowNames'
pxFererl1_Table_Pa.Properties.VariableNames = CellProperties;

%For pxFererl2
pxFererl2_Table_Xy=table(Species_pxFererl2_Xy, cellType_pxFererl2_Xy, propertiesXylem_pxFererl2(:,2),propertiesXylem_pxFererl2(:,3),propertiesXylem_pxFererl2(:,4)); %the name of the rows come after 'RowNames'
pxFererl2_Table_Xy.Properties.VariableNames = CellProperties;

pxFererl2_Table_Fi = table(Species_pxFererl2_Fi, cellType_pxFererl2_Fi, propertiesFiber_pxFererl2(:,2),propertiesFiber_pxFererl2(:,3),propertiesFiber_pxFererl2(:,4)); %the name of the rows come after 'RowNames'
pxFererl2_Table_Fi.Properties.VariableNames = CellProperties;

pxFererl2_Table_Ph = table(Species_pxFererl2_Ph, cellType_pxFererl2_Ph, propertiesPhloem_pxFererl2(:,2),propertiesPhloem_pxFererl2(:,3),propertiesPhloem_pxFererl2(:,4)); %the name of the rows come after 'RowNames'
pxFererl2_Table_Ph.Properties.VariableNames = CellProperties;

pxFererl2_Table_Pa = table(Species_pxFererl2_Pa, cellType_pxFererl2_Pa, propertiesParynchema_pxFererl2(:,2),propertiesParynchema_pxFererl2(:,3),propertiesParynchema_pxFererl2(:,4)); %the name of the rows come after 'RowNames'
pxFererl2_Table_Pa.Properties.VariableNames = CellProperties;

%For pxFerF

pxFerF_Table_Xy=table(Species_pxFerF_Xy, cellType_pxFerF_Xy, propertiesXylem_pxFerF(:,2),propertiesXylem_pxFerF(:,3),propertiesXylem_pxFerF(:,4)); %the name of the rows come after 'RowNames'
pxFerF_Table_Xy.Properties.VariableNames = CellProperties;

pxFerF_Table_Ph = table(Species_pxFerF_Ph, cellType_pxFerF_Ph, propertiesPhloem_pxFerF(:,2),propertiesPhloem_pxFerF(:,3),propertiesPhloem_pxFerF(:,4)); %the name of the rows come after 'RowNames'
pxFerF_Table_Ph.Properties.VariableNames = CellProperties;

pxFerF_Table_Pa = table(Species_pxFerF_Pa, cellType_pxFerF_Pa, propertiesParynchema_pxFerF(:,2),propertiesParynchema_pxFerF(:,3),propertiesParynchema_pxFerF(:,4)); %the name of the rows come after 'RowNames'
pxFerF_Table_Pa.Properties.VariableNames = CellProperties;


%create Excel files for each species and cell types

%WT
filename_WT_Xy='WT_Table_Xy_tidy.xlsx';
writetable(WT_Table_Xy, filename_WT_Xy);

filename_WT_Fi='WT_Table_Fi_tidy.xlsx';
writetable(WT_Table_Fi, filename_WT_Fi);

filename_WT_Ph='WT_Table_Ph_tidy.xlsx';
writetable(WT_Table_Ph, filename_WT_Ph);

filename_WT_Pa='WT_Table_Pa_tidy.xlsx';
writetable(WT_Table_Pa, filename_WT_Pa);

%pxF
filename_pxF_Xy='pxF_Table_Xy_tidy.xlsx';
writetable(pxF_Table_Xy, filename_pxF_Xy);

filename_pxF_Fi='pxF_Table_Fi_tidy.xlsx';
writetable(pxF_Table_Fi, filename_pxF_Fi);

filename_pxF_Ph='pxF_Table_Ph_tidy.xlsx';
writetable(pxF_Table_Ph, filename_pxF_Ph);

filename_pxF_Pa='pxF_Table_Pa_tidy.xlsx';
writetable(pxF_Table_Pa, filename_pxF_Pa);

%pxFer
filename_pxFer_Xy='pxFer_Table_Xy_tidy.xlsx';
writetable(pxFer_Table_Xy, filename_pxFer_Xy);

filename_pxFer_Fi='pxFer_Table_Fi_tidy.xlsx';
writetable(pxFer_Table_Fi, filename_pxFer_Fi);

filename_pxFer_Ph='pxFer_Table_Ph_tidy.xlsx';
writetable(pxFer_Table_Ph, filename_pxFer_Ph);

filename_pxFer_Pa='pxFer_Table_Pa_tidy.xlsx';
writetable(pxFer_Table_Pa, filename_pxFer_Pa);

%pxFererl1

filename_pxFererl1_Xy='pxFererl1_Table_Xy_tidy.xlsx';
writetable(pxFererl1_Table_Xy, filename_pxFererl1_Xy);

filename_pxFererl1_Fi='pxFererl1_Table_Fi_tidy.xlsx';
writetable(pxFererl1_Table_Fi, filename_pxFererl1_Fi);

filename_pxFererl1_Ph='pxFererl1_Table_Ph_tidy.xlsx';
writetable(pxFererl1_Table_Ph, filename_pxFererl1_Ph);

filename_pxFererl1_Pa='pxFererl1_Table_Pa_tidy.xlsx';
writetable(pxFererl1_Table_Pa, filename_pxFererl1_Pa);

%pxFererl2

filename_pxFererl2_Xy='pxFererl2_Table_Xy_tidy.xlsx';
writetable(pxFererl2_Table_Xy, filename_pxFererl2_Xy);

filename_pxFererl2_Fi='pxFererl2_Table_Fi_tidy.xlsx';
writetable(pxFererl2_Table_Fi, filename_pxFererl2_Fi);

filename_pxFererl2_Ph='pxFererl2_Table_Ph_tidy.xlsx';
writetable(pxFererl2_Table_Ph, filename_pxFererl2_Ph);

filename_pxFererl2_Pa='pxFererl2_Table_Pa_tidy.xlsx';
writetable(pxFererl2_Table_Pa, filename_pxFererl2_Pa);

%pxFerF

filename_pxFerF_Xy='pxFerF_Table_Xy_tidy.xlsx';
writetable(pxFerF_Table_Xy, filename_pxFerF_Xy);

filename_pxFerF_Ph='pxFerF_Table_Ph_tidy.xlsx';
writetable(pxFerF_Table_Ph, filename_pxFerF_Ph);

filename_pxFerF_Pa='pxFerF_Table_Pa_tidy.xlsx';
writetable(pxFerF_Table_Pa, filename_pxFerF_Pa);
