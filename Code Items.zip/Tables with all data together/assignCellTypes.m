function[cellType_Xy,cellType_Fi,cellType_Ph,cellType_Pa]=assignCellTypes(propertiesXylem,propertiesFiber,propertiesPhloem,propertiesParynchema)
cellTypes={'Xylem' 'Fiber' 'Phloem' 'Parynchema'};
cellType_Xy=repmat(cellTypes(1),size(propertiesXylem(:,1)),1);
cellType_Fi=repmat(cellTypes(2),size(propertiesFiber(:,1)),1);
cellType_Ph=repmat(cellTypes(3),size(propertiesPhloem(:,1)),1);
cellType_Pa=repmat(cellTypes(4),size(propertiesParynchema(:,1)),1);