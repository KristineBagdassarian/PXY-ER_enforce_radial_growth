function[propertiesXylem,propertiesPhloem,propertiesParynchema]=extractCellPropertiesNoFiber(sourceFolder)
%sourceWT = 'C:\Users\NBuser\Documents\MATLAB\Images\WT';
images =dir(fullfile(sourceFolder,'*.png'));
numFiles = length(images); %how many images in the folder

%start with a row of zeros to build tables
[propertiesXylem, propertiesPhloem, propertiesParynchema] = deal(zeros(4,1)');

%loop over images
for k = length(images):-1:1
[Xylem_Table_Num, Phloem_Table_Num, Parynchema_Table_Num]=splitExportNoFiber(images(k).name,sourceFolder);
    propertiesXylem=vertcat(propertiesXylem, Xylem_Table_Num);
    propertiesPhloem=vertcat(propertiesPhloem, Phloem_Table_Num);
    propertiesParynchema=vertcat(propertiesParynchema, Parynchema_Table_Num);
end

%remove zeros and convert pixels to microns
[propertiesXylem, propertiesPhloem, propertiesParynchema]=convert2MicronsNoFiber(propertiesXylem, propertiesPhloem, propertiesParynchema);
