function[Species_Xy,Species_Fi,Species_Ph]=assignSpeciesStems(propertiesXylem,propertiesFiber,propertiesPhloem,speciesName)

Species_Xy=repmat(speciesName,size(propertiesXylem(:,1)),1);
Species_Fi=repmat(speciesName,size(propertiesFiber(:,1)),1);
Species_Ph=repmat(speciesName,size(propertiesPhloem(:,1)),1);
