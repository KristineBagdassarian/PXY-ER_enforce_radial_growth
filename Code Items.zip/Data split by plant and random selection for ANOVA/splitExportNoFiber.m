function[Xylem_Table_Num_WT, Phloem_Table_Num_WT, Parynchema_Table_Num_WT]=splitExportNoFiber(baseFileName,source)
%this function takes the 'name' for a source and the base name for an image
%reads the image and returns table of properties for that image
TypeXylem=1000; TypeEpidermis=3000; TypePhloem=4000; TypeProcambium=5000; TypeParynchema=6000;
TypeZero=0;
%for k = length(imagesWT):-1:1
   % baseFileName = imagesWT(k).name; %basic filename (the name before the '.png')
    fullFileName = fullfile(source, baseFileName); %combine for every filename
    imageRead= imread(fullFileName); %read each image
    [Ix,Iph,Ipa]=imagesNewNoFiber(imageRead); %separate the cell images for each
     %for the table of properties
    [Ix_cc,Iph_cc,Ipa_cc]=ConnectedComponentsNoFiber(Ix,Iph,Ipa); %connected components for each cell type
    Xylem_Table_Num_WT=NumberProperties(Ix_cc,TypeXylem);
    Phloem_Table_Num_WT=NumberProperties(Iph_cc,TypePhloem);
    Parynchema_Table_Num_WT=NumberProperties(Ipa_cc,TypeParynchema);
 