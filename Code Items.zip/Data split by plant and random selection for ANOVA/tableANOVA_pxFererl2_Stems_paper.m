%this programme extracts the properties of coloured cells from images
%the images are of cross-sections of plant stems; Each image has 
%a number of cell types manually selected and coloured. Each selected cell type
%uses a colour which is the same for all images, through all the different genotypes.
%The properties of the cells are assessed in the following way. The images are
%accessed from the folder by the programme. The images are then split into
%multiple binary images according to cell types. The cells in each image
%are then white objects on black background whose properties can be
%measured as the properties of white connected components. The programme
%below does this and then converts the pixel data into micros using a
%spatial factor which is separately calculated from the images using known
%size data and callibration ruler. The code produces files with each row
%containing data for a specific cell type for a specific plant. So in the
%file, the first row would contain all of the data for plant 1 of a
%particular genotype, row 2 would contain the data for plant 2 of the same
%plant and so on. This data will then be transformed to be assesed in R.


%For pxFererl2 stems


%calculate spatial and length factors for conversion from pixels to microns
SpatialFactor_Area=[10/36]*[10/36];
SpatialFactor_Length=[10/36];

%access the folder with pxFererl2 images
sourcepxFererl2 = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxFererl2';
imagespxFererl2 =dir(fullfile(sourcepxFererl2,'*.png'));
numFiles = length(imagespxFererl2); %how many images in the folder

%create an excell spreadsheet with the areas of each individual pxFererl2
%plant's cells in a row (e.g. row 1 contains the areas of pxFererl21)
for k = length(imagespxFererl2):-1:1
[Xylem_Table_Num_pxFererl2, Fiber_Table_Num_pxFererl2,Phloem_Table_Num_pxFererl2]=splitExportStems(imagespxFererl2(k).name,sourcepxFererl2);
    %select the rows in order for area
    my_cell = sprintf( 'A%s',num2str(k) );
    %create rows with area data for xylem(unedited)
    Xylem_Table_Num_pxFererl2(:,2)=Xylem_Table_Num_pxFererl2(:,2)*SpatialFactor_Area;
    xlswrite('Xylem_allpxFererl2.xlsx',Xylem_Table_Num_pxFererl2(:,2)',1,my_cell);
    %create rows with area data for fiber(unedited)
    Fiber_Table_Num_pxFererl2(:,2)=Fiber_Table_Num_pxFererl2(:,2)*SpatialFactor_Area;
    xlswrite('Fiber_allpxFererl2.xlsx',Fiber_Table_Num_pxFererl2(:,2)',1,my_cell);
    %create rows with area data for phloem(unedited)
    Phloem_Table_Num_pxFererl2(:,2)=Phloem_Table_Num_pxFererl2(:,2)*SpatialFactor_Area;
    xlswrite('Phloem_allpxFererl2.xlsx',Phloem_Table_Num_pxFererl2(:,2)',1,my_cell);
    
    %select the rows in order for perimeter
     
    Xylem_Table_Num_pxFererl2(:,4)=Xylem_Table_Num_pxFererl2(:,4)*SpatialFactor_Length;
    xlswrite('Xylem_allpxFererl2_per.xlsx',Xylem_Table_Num_pxFererl2(:,4)',1,my_cell);
    %create rows with perimeter data for fiber(unedited)
    Fiber_Table_Num_pxFererl2(:,4)=Fiber_Table_Num_pxFererl2(:,4)*SpatialFactor_Length;
    xlswrite('Fiber_allpxFererl2_per.xlsx',Fiber_Table_Num_pxFererl2(:,4)',1,my_cell);
    %create rows with perimeter data for phloem(unedited)
    Phloem_Table_Num_pxFererl2(:,4)=Phloem_Table_Num_pxFererl2(:,4)*SpatialFactor_Length;
    xlswrite('Phloem_allpxFererl2_per.xlsx',Phloem_Table_Num_pxFererl2(:,4)',1,my_cell);
     
    %select the rows in order for ellipticity
    
    Xylem_Table_Num_pxFererl2(:,3)=Xylem_Table_Num_pxFererl2(:,3);
    xlswrite('Xylem_allpxFererl2_el.xlsx',Xylem_Table_Num_pxFererl2(:,3)',1,my_cell);
    %create rows with ellipticity data for fiber(unedited)
    Fiber_Table_Num_pxFererl2(:,3)=Fiber_Table_Num_pxFererl2(:,3);
    xlswrite('Fiber_allpxFererl2_el.xlsx',Fiber_Table_Num_pxFererl2(:,3)',1,my_cell);
    %create rows with ellipticity data for phloem(unedited)
    Phloem_Table_Num_pxFererl2(:,3)=Phloem_Table_Num_pxFererl2(:,3);
    xlswrite('Phloem_allpxFererl2_el.xlsx',Phloem_Table_Num_pxFererl2(:,3)',1,my_cell);
    
end

%we now import it back

%xylem
importpxFererl2xy=xlsread('Xylem_allpxFererl2.xlsx');
importpxFererl2xy_per=xlsread('Xylem_allpxFererl2_per.xlsx');
importpxFererl2xy_el=xlsread('Xylem_allpxFererl2_el.xlsx');
[rows, y]=size(importpxFererl2xy);
%fiber
importpxFererl2fi=xlsread('Fiber_allpxFererl2.xlsx');
importpxFererl2fi_per=xlsread('Fiber_allpxFererl2_per.xlsx');
importpxFererl2fi_el=xlsread('Fiber_allpxFererl2_el.xlsx');
%phloem
importpxFererl2ph=xlsread('Phloem_allpxFererl2.xlsx');
importpxFererl2ph_per=xlsread('Phloem_allpxFererl2_per.xlsx');
importpxFererl2ph_el=xlsread('Phloem_allpxFererl2_el.xlsx');
rowProperties_xy_all=[0];
rowProperties_xy_all_per=[0];
rowProperties_xy_all_el=[0];

%remove NaN numbers from data and generate a file with properties of
%different cell types for that particular plant genotype

%for xylem

for k = rows:-1:1
    for j = rows:-1:1
        %for area
        rowProperties_xy=importpxFererl2xy(j,:);rowProperties_xy(isnan(rowProperties_xy))=[];
        rowProperties_xy_all=vertcat(rowProperties_xy_all,rowProperties_xy');
        
        %for perimeter
         rowProperties_xy_per=importpxFererl2xy_per(j,:);rowProperties_xy_per(isnan(rowProperties_xy_per))=[];
        rowProperties_xy_all_per=vertcat(rowProperties_xy_all_per,rowProperties_xy_per');
        
        %for ellipticity
         rowProperties_xy_el=importpxFererl2xy_el(j,:);rowProperties_xy_el(isnan(rowProperties_xy_el))=[];
        rowProperties_xy_all_el=vertcat(rowProperties_xy_all_el,rowProperties_xy_el');
    end
    
        rowProperties_xy=importpxFererl2xy(k,:);rowProperties_xy(isnan(rowProperties_xy))=[];
        rowProperties_xy_per=importpxFererl2xy_per(k,:);rowProperties_xy_per(isnan(rowProperties_xy_per))=[];
        rowProperties_xy_el=importpxFererl2xy_el(k,:);rowProperties_xy_el(isnan(rowProperties_xy_el))=[];

        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Xylem_all_plants_pxFererl2.xlsx',rowProperties_xy,1,my_cell_new);
        xlswrite('Xylem_all_plants_pxFererl2_per.xlsx',rowProperties_xy_per,1,my_cell_new);
        xlswrite('Xylem_all_plants_pxFererl2_el.xlsx',rowProperties_xy_el,1,my_cell_new);
end

%for fiber

rowProperties_fi_all=[0];
rowProperties_fi_all_per=[0];
rowProperties_fi_all_el=[0];

for k = rows:-1:1
    for j = rows:-1:1
        rowProperties_fi=importpxFererl2fi(j,:);rowProperties_fi(isnan(rowProperties_fi))=[];
        rowProperties_fi_all=vertcat(rowProperties_fi_all,rowProperties_fi');
        
        %for perimeter
        rowProperties_fi_per=importpxFererl2fi_per(j,:);rowProperties_fi_per(isnan(rowProperties_fi_per))=[];
        rowProperties_fi_all_per=vertcat(rowProperties_fi_all_per,rowProperties_fi_per');
        %for ellipticity
        rowProperties_fi_el=importpxFererl2fi_el(j,:);rowProperties_fi_el(isnan(rowProperties_fi_el))=[];
        rowProperties_fi_all_el=vertcat(rowProperties_fi_all_el,rowProperties_fi_el');
    end
    
        rowProperties_fi=importpxFererl2fi(k,:);rowProperties_fi(isnan(rowProperties_fi))=[];
        rowProperties_fi_per=importpxFererl2fi_per(k,:);rowProperties_fi_per(isnan(rowProperties_fi_per))=[];
        rowProperties_fi_el=importpxFererl2fi_el(k,:);rowProperties_fi_el(isnan(rowProperties_fi_el))=[];

        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Fiber_all_plants_pxFererl2.xlsx',rowProperties_fi,1,my_cell_new);
        xlswrite('Fiber_all_plants_pxFererl2_per.xlsx',rowProperties_fi_per,1,my_cell_new);
        xlswrite('Fiber_all_plants_pxFererl2_el.xlsx',rowProperties_fi_el,1,my_cell_new);
end

%for phloem

rowProperties_ph_all=[0];
rowProperties_ph_all_per=[0];
rowProperties_ph_all_el=[0];

for k = rows:-1:1
    for j = rows:-1:1
        rowProperties_ph=importpxFererl2ph(j,:);rowProperties_ph(isnan(rowProperties_ph))=[];
        rowProperties_ph_all=vertcat(rowProperties_ph_all,rowProperties_ph');
        
        rowProperties_ph_per=importpxFererl2ph_per(j,:);rowProperties_ph_per(isnan(rowProperties_ph_per))=[];
        rowProperties_ph_all_per=vertcat(rowProperties_ph_all_per,rowProperties_ph_per');
        
        rowProperties_ph_el=importpxFererl2ph_el(j,:);rowProperties_ph_el(isnan(rowProperties_ph_el))=[];
        rowProperties_ph_all_el=vertcat(rowProperties_ph_all_el,rowProperties_ph_el');
    end
    
        rowProperties_ph=importpxFererl2ph(k,:);rowProperties_ph(isnan(rowProperties_ph))=[];
        rowProperties_ph_per=importpxFererl2ph_per(k,:);rowProperties_ph_per(isnan(rowProperties_ph_per))=[];
        rowProperties_ph_el=importpxFererl2ph_el(k,:);rowProperties_ph_el(isnan(rowProperties_ph_el))=[];
 
        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Phloem_all_plants_pxFererl2.xlsx',rowProperties_ph,1,my_cell_new);
        xlswrite('Phloem_all_plants_pxFererl2_per.xlsx',rowProperties_ph_per,1,my_cell_new);
        xlswrite('Phloem_all_plants_pxFererl2_el.xlsx',rowProperties_ph_el,1,my_cell_new);
end



