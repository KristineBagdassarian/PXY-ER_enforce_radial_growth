%this programme extracts the properties of coloured cells from images
%the images are of cross-sections of plant stems; Each image has 
%a number of cell types manually selected and coloured. Each selected cell type
%uses a colour which is the same for all images, through all the different genotypes.
%The properties of the cells are assessed in the following way. The images are
%accessed from the folder by the programme. The images are then split into
%multiple binary images according to cell types. The cells in each image
%are then white objects on black background whose properties can be
%measured as the properties of white connected components. The programme
%below does this and then converts the pixel data into micros using a
%spatial factor which is separately calculated from the images using known
%size data and callibration ruler. The code produces files with each row
%containing data for a specific cell type for a specific plant. So in the
%file, the first row would contain all of the data for plant 1 of a
%particular genotype, row 2 would contain the data for plant 2 of the same
%plant and so on. This data will then be transformed to be assesed in R.


%For pxF stems

%calculate spatial and length factors for conversion from pixels to microns
SpatialFactor_Area=[10/36]*[10/36];
SpatialFactor_Length=[10/36];

%access the folder with pxF images
sourcepxF = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxF';
imagespxF =dir(fullfile(sourcepxF,'*.png'));
numFiles = length(imagespxF); %how many images in the folder

%create an excell spreadsheet with the areas of each individual pxF
%plant's cells in a row (e.g. row 1 contains the areas of pxF1)
for k = length(imagespxF):-1:1
[Xylem_Table_Num_pxF, Fiber_Table_Num_pxF,Phloem_Table_Num_pxF]=splitExportStems(imagespxF(k).name,sourcepxF);
    %select the rows in order for area
    my_cell = sprintf( 'A%s',num2str(k) );
    %create rows with area data for xylem(unedited)
    Xylem_Table_Num_pxF(:,2)=Xylem_Table_Num_pxF(:,2)*SpatialFactor_Area;
    xlswrite('Xylem_allpxF.xlsx',Xylem_Table_Num_pxF(:,2)',1,my_cell);
    %create rows with area data for fiber(unedited)
    Fiber_Table_Num_pxF(:,2)=Fiber_Table_Num_pxF(:,2)*SpatialFactor_Area;
    xlswrite('Fiber_allpxF.xlsx',Fiber_Table_Num_pxF(:,2)',1,my_cell);
    %create rows with area data for phloem(unedited)
    Phloem_Table_Num_pxF(:,2)=Phloem_Table_Num_pxF(:,2)*SpatialFactor_Area;
    xlswrite('Phloem_allpxF.xlsx',Phloem_Table_Num_pxF(:,2)',1,my_cell);
    
    %select the rows in order for perimeter
     
    Xylem_Table_Num_pxF(:,4)=Xylem_Table_Num_pxF(:,4)*SpatialFactor_Length;
    xlswrite('Xylem_allpxF_per.xlsx',Xylem_Table_Num_pxF(:,4)',1,my_cell);
    %create rows with perimeter data for fiber(unedited)
    Fiber_Table_Num_pxF(:,4)=Fiber_Table_Num_pxF(:,4)*SpatialFactor_Length;
    xlswrite('Fiber_allpxF_per.xlsx',Fiber_Table_Num_pxF(:,4)',1,my_cell);
    %create rows with perimeter data for phloem(unedited)
    Phloem_Table_Num_pxF(:,4)=Phloem_Table_Num_pxF(:,4)*SpatialFactor_Length;
    xlswrite('Phloem_allpxF_per.xlsx',Phloem_Table_Num_pxF(:,4)',1,my_cell);
     
    %select the rows in order for ellipticity
    
    Xylem_Table_Num_pxF(:,3)=Xylem_Table_Num_pxF(:,3);
    xlswrite('Xylem_allpxF_el.xlsx',Xylem_Table_Num_pxF(:,3)',1,my_cell);
    %create rows with ellipticity data for fiber(unedited)
    Fiber_Table_Num_pxF(:,3)=Fiber_Table_Num_pxF(:,3);
    xlswrite('Fiber_allpxF_el.xlsx',Fiber_Table_Num_pxF(:,3)',1,my_cell);
    %create rows with ellipticity data for phloem(unedited)
    Phloem_Table_Num_pxF(:,3)=Phloem_Table_Num_pxF(:,3);
    xlswrite('Phloem_allpxF_el.xlsx',Phloem_Table_Num_pxF(:,3)',1,my_cell);
    
end

%we now import it back

%xylem
importpxFxy=xlsread('Xylem_allpxF.xlsx');
importpxFxy_per=xlsread('Xylem_allpxF_per.xlsx');
importpxFxy_el=xlsread('Xylem_allpxF_el.xlsx');
[rows, y]=size(importpxFxy);
%fiber
importpxFfi=xlsread('Fiber_allpxF.xlsx');
importpxFfi_per=xlsread('Fiber_allpxF_per.xlsx');
importpxFfi_el=xlsread('Fiber_allpxF_el.xlsx');
%phloem
importpxFph=xlsread('Phloem_allpxF.xlsx');
importpxFph_per=xlsread('Phloem_allpxF_per.xlsx');
importpxFph_el=xlsread('Phloem_allpxF_el.xlsx');
rowProperties_xy_all=[0];
rowProperties_xy_all_per=[0];
rowProperties_xy_all_el=[0];

%remove NaN numbers from data and generate a file with properties of
%different cell types for that particular plant genotype

%for xylem

for k = rows:-1:1
    for j = rows:-1:1
        %for area
        rowProperties_xy=importpxFxy(j,:);rowProperties_xy(isnan(rowProperties_xy))=[];
        rowProperties_xy_all=vertcat(rowProperties_xy_all,rowProperties_xy');
        
        %for perimeter
         rowProperties_xy_per=importpxFxy_per(j,:);rowProperties_xy_per(isnan(rowProperties_xy_per))=[];
        rowProperties_xy_all_per=vertcat(rowProperties_xy_all_per,rowProperties_xy_per');
        
        %for ellipticity
         rowProperties_xy_el=importpxFxy_el(j,:);rowProperties_xy_el(isnan(rowProperties_xy_el))=[];
        rowProperties_xy_all_el=vertcat(rowProperties_xy_all_el,rowProperties_xy_el');
    end
    
        rowProperties_xy=importpxFxy(k,:);rowProperties_xy(isnan(rowProperties_xy))=[];
        rowProperties_xy_per=importpxFxy_per(k,:);rowProperties_xy_per(isnan(rowProperties_xy_per))=[];
        rowProperties_xy_el=importpxFxy_el(k,:);rowProperties_xy_el(isnan(rowProperties_xy_el))=[];

        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Xylem_all_plants_pxF.xlsx',rowProperties_xy,1,my_cell_new);
        xlswrite('Xylem_all_plants_pxF_per.xlsx',rowProperties_xy_per,1,my_cell_new);
        xlswrite('Xylem_all_plants_pxF_el.xlsx',rowProperties_xy_el,1,my_cell_new);
end

%for fiber

rowProperties_fi_all=[0];
rowProperties_fi_all_per=[0];
rowProperties_fi_all_el=[0];

for k = rows:-1:1
    for j = rows:-1:1
        rowProperties_fi=importpxFfi(j,:);rowProperties_fi(isnan(rowProperties_fi))=[];
        rowProperties_fi_all=vertcat(rowProperties_fi_all,rowProperties_fi');
        
        %for perimeter
        rowProperties_fi_per=importpxFfi_per(j,:);rowProperties_fi_per(isnan(rowProperties_fi_per))=[];
        rowProperties_fi_all_per=vertcat(rowProperties_fi_all_per,rowProperties_fi_per');
        %for ellipticity
        rowProperties_fi_el=importpxFfi_el(j,:);rowProperties_fi_el(isnan(rowProperties_fi_el))=[];
        rowProperties_fi_all_el=vertcat(rowProperties_fi_all_el,rowProperties_fi_el');
    end
        rowProperties_fi=importpxFfi(k,:);rowProperties_fi(isnan(rowProperties_fi))=[];
        rowProperties_fi_per=importpxFfi_per(k,:);rowProperties_fi_per(isnan(rowProperties_fi_per))=[];
        rowProperties_fi_el=importpxFfi_el(k,:);rowProperties_fi_el(isnan(rowProperties_fi_el))=[];

        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Fiber_all_plants_pxF.xlsx',rowProperties_fi,1,my_cell_new);
        xlswrite('Fiber_all_plants_pxF_per.xlsx',rowProperties_fi_per,1,my_cell_new);
        xlswrite('Fiber_all_plants_pxF_el.xlsx',rowProperties_fi_el,1,my_cell_new);
end

%for phloem

rowProperties_ph_all=[0];
rowProperties_ph_all_per=[0];
rowProperties_ph_all_el=[0];

for k = rows:-1:1
    for j = rows:-1:1
        rowProperties_ph=importpxFph(j,:);rowProperties_ph(isnan(rowProperties_ph))=[];
        rowProperties_ph_all=vertcat(rowProperties_ph_all,rowProperties_ph');
        
        rowProperties_ph_per=importpxFph_per(j,:);rowProperties_ph_per(isnan(rowProperties_ph_per))=[];
        rowProperties_ph_all_per=vertcat(rowProperties_ph_all_per,rowProperties_ph_per');
        
        rowProperties_ph_el=importpxFph_el(j,:);rowProperties_ph_el(isnan(rowProperties_ph_el))=[];
        rowProperties_ph_all_el=vertcat(rowProperties_ph_all_el,rowProperties_ph_el');
    end
    
        rowProperties_ph=importpxFph(k,:);rowProperties_ph(isnan(rowProperties_ph))=[];
        rowProperties_ph_per=importpxFph_per(k,:);rowProperties_ph_per(isnan(rowProperties_ph_per))=[];
        rowProperties_ph_el=importpxFph_el(k,:);rowProperties_ph_el(isnan(rowProperties_ph_el))=[];
  
        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Phloem_all_plants_pxF.xlsx',rowProperties_ph,1,my_cell_new);
        xlswrite('Phloem_all_plants_pxF_per.xlsx',rowProperties_ph_per,1,my_cell_new);
        xlswrite('Phloem_all_plants_pxF_el.xlsx',rowProperties_ph_el,1,my_cell_new);
end



