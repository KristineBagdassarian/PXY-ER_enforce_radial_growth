%this programme extracts the properties of coloured cells from images
%the images are of cross-sections of plant hypocotyls; Each image has 
%a number of cell types manually selected and coloured. Each selected cell type
%uses a colour which is the same for all images, through all the different genotypes.
%The properties of the cells are assessed in the following way. The images are
%accessed from the folder by the programme. The images are then split into
%multiple binary images according to cell types. The cells in each image
%are then white objects on black background whose properties can be
%measured as the properties of white connected components. The programme
%below does this and then converts the pixel data into micros using a
%spatial factor which is separately calculated from the images using known
%size data and callibration ruler. The code produces files with each row
%containing data for a specific cell type for a specific plant. So in the
%file, the first row would contain all of the data for plant 1 of a
%particular genotype, row 2 would contain the data for plant 2 of the same
%plant and so on. This data will then be transformed to be assesed in R.


%For pxFerF hypocotyls

%calculate spatial and length factors for conversion from pixels to microns
SpatialFactor_Area=[10/33]*[10/33];
SpatialFactor_Length=[10/33];

%access the folder with pxFerF images
sourcepxFerF = 'C:\Users\NBuser\Documents\MATLAB\Images Paper\Coloured Images\pxFerF';
imagespxFerF =dir(fullfile(sourcepxFerF,'*.png'));
numFiles = length(imagespxFerF); %how many images in the folder

%create an excell spreadsheet with the areas of each individual pxFerF
%plant's cells in a row (e.g. row 1 contains the areas of pxFerF1)
for k = length(imagespxFerF):-1:1
[Xylem_Table_Num_pxFerF, Phloem_Table_Num_pxFerF, Parynchema_Table_Num_pxFerF]=splitExportNoFiber(imagespxFerF(k).name,sourcepxFerF);
    %select the rows in order for area
    my_cell = sprintf( 'A%s',num2str(k) );
    %create rows with area data for xylem(unedited)
    Xylem_Table_Num_pxFerF(:,2)=Xylem_Table_Num_pxFerF(:,2)*SpatialFactor_Area;
    xlswrite('Xylem_allpxFerF.xlsx',Xylem_Table_Num_pxFerF(:,2)',1,my_cell);
    %create rows with area data for phloem(unedited)
    Phloem_Table_Num_pxFerF(:,2)=Phloem_Table_Num_pxFerF(:,2)*SpatialFactor_Area;
    xlswrite('Phloem_allpxFerF.xlsx',Phloem_Table_Num_pxFerF(:,2)',1,my_cell);
    %create rows with area data for parynchema(unedited)
    Parynchema_Table_Num_pxFerF(:,2)=Parynchema_Table_Num_pxFerF(:,2)*SpatialFactor_Area;
    xlswrite('Parynchema_allpxFerF.xlsx',Parynchema_Table_Num_pxFerF(:,2)',1,my_cell);
    
    %select the rows in order for perimeter
     
    Xylem_Table_Num_pxFerF(:,4)=Xylem_Table_Num_pxFerF(:,4)*SpatialFactor_Length;
    xlswrite('Xylem_allpxFerF_per.xlsx',Xylem_Table_Num_pxFerF(:,4)',1,my_cell);
    %create rows with perimeter data for phloem(unedited)
    Phloem_Table_Num_pxFerF(:,4)=Phloem_Table_Num_pxFerF(:,4)*SpatialFactor_Length;
    xlswrite('Phloem_allpxFerF_per.xlsx',Phloem_Table_Num_pxFerF(:,4)',1,my_cell);
    %for parynchema
    Parynchema_Table_Num_pxFerF(:,4)=Parynchema_Table_Num_pxFerF(:,4)*SpatialFactor_Length;
    xlswrite('Parynchema_allpxFerF_per.xlsx',Parynchema_Table_Num_pxFerF(:,4)',1,my_cell);
    %select the rows in order for ellipticity
    
    Xylem_Table_Num_pxFerF(:,3)=Xylem_Table_Num_pxFerF(:,3);
    xlswrite('Xylem_allpxFerF_el.xlsx',Xylem_Table_Num_pxFerF(:,3)',1,my_cell);
    %create rows with ellipticity data for phloem(unedited)
    Phloem_Table_Num_pxFerF(:,3)=Phloem_Table_Num_pxFerF(:,3);
    xlswrite('Phloem_allpxFerF_el.xlsx',Phloem_Table_Num_pxFerF(:,3)',1,my_cell);
    %create rows for parynchema
    Parynchema_Table_Num_pxFerF(:,3)=Parynchema_Table_Num_pxFerF(:,3);
    xlswrite('Parynchema_allpxFerF_el.xlsx',Parynchema_Table_Num_pxFerF(:,3)',1,my_cell);
    
end

%we now import it back

%xylem
importpxFerFxy=xlsread('Xylem_allpxFerF.xlsx');
importpxFerFxy_per=xlsread('Xylem_allpxFerF_per.xlsx');
importpxFerFxy_el=xlsread('Xylem_allpxFerF_el.xlsx');
[rows, y]=size(importpxFerFxy);
%phloem
importpxFerFph=xlsread('Phloem_allpxFerF.xlsx');
importpxFerFph_per=xlsread('Phloem_allpxFerF_per.xlsx');
importpxFerFph_el=xlsread('Phloem_allpxFerF_el.xlsx');
%parynchema
importpxFerFpa=xlsread('Parynchema_allpxFerF.xlsx');
importpxFerFpa_per=xlsread('Parynchema_allpxFerF_per.xlsx');
importpxFerFpa_el=xlsread('Parynchema_allpxFerF_el.xlsx');

rowProperties_xy_all=[0];
rowProperties_xy_all_per=[0];
rowProperties_xy_all_el=[0];

%remove NaN numbers from data and generate a file with properties of
%different cell types for that particular plant genotype
%for xylem

for k = rows:-1:1
    for j = rows:-1:1
        %for area
        rowProperties_xy=importpxFerFxy(j,:);rowProperties_xy(isnan(rowProperties_xy))=[];
        rowProperties_xy_all=vertcat(rowProperties_xy_all,rowProperties_xy');
        
        %for perimeter
         rowProperties_xy_per=importpxFerFxy_per(j,:);rowProperties_xy_per(isnan(rowProperties_xy_per))=[];
        rowProperties_xy_all_per=vertcat(rowProperties_xy_all_per,rowProperties_xy_per');
        
        %for ellipticity
         rowProperties_xy_el=importpxFerFxy_el(j,:);rowProperties_xy_el(isnan(rowProperties_xy_el))=[];
        rowProperties_xy_all_el=vertcat(rowProperties_xy_all_el,rowProperties_xy_el');
    end
    
        rowProperties_xy=importpxFerFxy(k,:);rowProperties_xy(isnan(rowProperties_xy))=[];
        rowProperties_xy_per=importpxFerFxy_per(k,:);rowProperties_xy_per(isnan(rowProperties_xy_per))=[];
        rowProperties_xy_el=importpxFerFxy_el(k,:);rowProperties_xy_el(isnan(rowProperties_xy_el))=[];
  
        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Xylem_all_plants_pxFerF.xlsx',rowProperties_xy,1,my_cell_new);
        xlswrite('Xylem_all_plants_pxFerF_per.xlsx',rowProperties_xy_per,1,my_cell_new);
        xlswrite('Xylem_all_plants_pxFerF_el.xlsx',rowProperties_xy_el,1,my_cell_new);
end

%for phloem

rowProperties_ph_all=[0];
rowProperties_ph_all_per=[0];
rowProperties_ph_all_el=[0];

for k = rows:-1:1
    for j = rows:-1:1
        rowProperties_ph=importpxFerFph(j,:);rowProperties_ph(isnan(rowProperties_ph))=[];
        rowProperties_ph_all=vertcat(rowProperties_ph_all,rowProperties_ph');
        
        rowProperties_ph_per=importpxFerFph_per(j,:);rowProperties_ph_per(isnan(rowProperties_ph_per))=[];
        rowProperties_ph_all_per=vertcat(rowProperties_ph_all_per,rowProperties_ph_per');
        
        rowProperties_ph_el=importpxFerFph_el(j,:);rowProperties_ph_el(isnan(rowProperties_ph_el))=[];
        rowProperties_ph_all_el=vertcat(rowProperties_ph_all_el,rowProperties_ph_el');
    end
    
        rowProperties_ph=importpxFerFph(k,:);rowProperties_ph(isnan(rowProperties_ph))=[];
        rowProperties_ph_per=importpxFerFph_per(k,:);rowProperties_ph_per(isnan(rowProperties_ph_per))=[];
        rowProperties_ph_el=importpxFerFph_el(k,:);rowProperties_ph_el(isnan(rowProperties_ph_el))=[];
 
        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Phloem_all_plants_pxFerF.xlsx',rowProperties_ph,1,my_cell_new);
        xlswrite('Phloem_all_plants_pxFerF_per.xlsx',rowProperties_ph_per,1,my_cell_new);
        xlswrite('Phloem_all_plants_pxFerF_el.xlsx',rowProperties_ph_el,1,my_cell_new);
end

%for phloem

rowProperties_pa_all=[0];
rowProperties_pa_all_per=[0];
rowProperties_pa_all_el=[0];

for k = rows:-1:1
    for j = rows:-1:1
        rowProperties_pa=importpxFerFpa(j,:);rowProperties_pa(isnan(rowProperties_pa))=[];
        rowProperties_pa_all=vertcat(rowProperties_pa_all,rowProperties_pa');
        
        rowProperties_pa_per=importpxFerFpa_per(j,:);rowProperties_pa_per(isnan(rowProperties_pa_per))=[];
        rowProperties_pa_all_per=vertcat(rowProperties_pa_all_per,rowProperties_pa_per');
        
        rowProperties_pa_el=importpxFerFpa_el(j,:);rowProperties_pa_el(isnan(rowProperties_pa_el))=[];
        rowProperties_pa_all_el=vertcat(rowProperties_pa_all_el,rowProperties_pa_el');
    end
    
        rowProperties_pa=importpxFerFpa(k,:);rowProperties_pa(isnan(rowProperties_pa))=[];
        rowProperties_pa_per=importpxFerFpa_per(k,:);rowProperties_pa_per(isnan(rowProperties_pa_per))=[];
        rowProperties_pa_el=importpxFerFpa_el(k,:);rowProperties_pa_el(isnan(rowProperties_pa_el))=[];
 
        my_cell_new = sprintf( 'A%s',num2str(k) );
        xlswrite('Parynchema_all_plants_pxFerF.xlsx',rowProperties_pa,1,my_cell_new);
        xlswrite('Parynchema_all_plants_pxFerF_per.xlsx',rowProperties_pa_per,1,my_cell_new);
        xlswrite('Parynchema_all_plants_pxFerF_el.xlsx',rowProperties_pa_el,1,my_cell_new);
end






