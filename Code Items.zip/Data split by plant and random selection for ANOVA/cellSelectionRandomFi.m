%This programme takes the files containing the various cell data per plant per genotype
%(using these files' names) and applies a function to them to remove the
%NaN's and any items smaller than 1 (the noise), then selects a random
%sample of data with the same size n from each plant and genotype, creating
%a file that's exported
%nuber of fiber cells selected per plant per genotype
n=35;

Fiber_all_plants_WT = 'Fiber_all_plants_WT.xlsx';
Fiber_all_plants_WT_per='Fiber_all_plants_WT_per.xlsx';
Fiber_all_plants_WT_el='Fiber_all_plants_WT_el.xlsx';
[Ridge_WT_Fi,Ridge_WT_Fi_per, Ridge_WT_Fi_el]=RandomSelectAll(Fiber_all_plants_WT,Fiber_all_plants_WT_per,Fiber_all_plants_WT_el, n);
xlswrite('Ridge_WT_Fi.xlsx',Ridge_WT_Fi);
xlswrite('Ridge_WT_Fi_per.xlsx',Ridge_WT_Fi_per);
xlswrite('Ridge_WT_Fi_el.xlsx',Ridge_WT_Fi_el);

%
Fiber_all_plants_pxF = 'Fiber_all_plants_pxF.xlsx';
Fiber_all_plants_pxF_per='Fiber_all_plants_pxF_per.xlsx';
Fiber_all_plants_pxF_el='Fiber_all_plants_pxF_el.xlsx';
[Ridge_pxF_Fi,Ridge_pxF_Fi_per, Ridge_pxF_Fi_el]=RandomSelectAll(Fiber_all_plants_pxF,Fiber_all_plants_pxF_per,Fiber_all_plants_pxF_el, n);
xlswrite('Ridge_pxF_Fi.xlsx',Ridge_pxF_Fi);
xlswrite('Ridge_pxF_Fi_per.xlsx',Ridge_pxF_Fi_per);
xlswrite('Ridge_pxF_Fi_el.xlsx',Ridge_pxF_Fi_el);

Fiber_all_plants_pxFer = 'Fiber_all_plants_pxFer.xlsx';
Fiber_all_plants_pxFer_per='Fiber_all_plants_pxFer_per.xlsx';
Fiber_all_plants_pxFer_el='Fiber_all_plants_pxFer_el.xlsx';
[Ridge_pxFer_Fi,Ridge_pxFer_Fi_per, Ridge_pxFer_Fi_el]=RandomSelectAll(Fiber_all_plants_pxFer,Fiber_all_plants_pxFer_per,Fiber_all_plants_pxFer_el, n);
xlswrite('Ridge_pxFer_Fi.xlsx',Ridge_pxFer_Fi);
xlswrite('Ridge_pxFer_Fi_per.xlsx',Ridge_pxFer_Fi_per);
xlswrite('Ridge_pxFer_Fi_el.xlsx',Ridge_pxFer_Fi_el);

Fiber_all_plants_pxFererl1 = 'Fiber_all_plants_pxFererl1.xlsx';
Fiber_all_plants_pxFererl1_per='Fiber_all_plants_pxFererl1_per.xlsx';
Fiber_all_plants_pxFererl1_el='Fiber_all_plants_pxFererl1_el.xlsx';
[Ridge_pxFererl1_Fi,Ridge_pxFererl1_Fi_per, Ridge_pxFererl1_Fi_el]=RandomSelectAll(Fiber_all_plants_pxFererl1,Fiber_all_plants_pxFererl1_per,Fiber_all_plants_pxFererl1_el, n);
xlswrite('Ridge_pxFererl1_Fi.xlsx',Ridge_pxFererl1_Fi);
xlswrite('Ridge_pxFererl1_Fi_per.xlsx',Ridge_pxFererl1_Fi_per);
xlswrite('Ridge_pxFererl1_Fi_el.xlsx',Ridge_pxFererl1_Fi_el);

Fiber_all_plants_pxFererl2 = 'Fiber_all_plants_pxFererl2.xlsx';
Fiber_all_plants_pxFererl2_per='Fiber_all_plants_pxFererl2_per.xlsx';
Fiber_all_plants_pxFererl2_el='Fiber_all_plants_pxFererl2_el.xlsx';
[Ridge_pxFererl2_Fi,Ridge_pxFererl2_Fi_per, Ridge_pxFererl2_Fi_el]=RandomSelectAll(Fiber_all_plants_pxFererl2,Fiber_all_plants_pxFererl2_per,Fiber_all_plants_pxFererl2_el, n);
xlswrite('Ridge_pxFererl2_Fi.xlsx',Ridge_pxFererl2_Fi);
xlswrite('Ridge_pxFererl2_Fi_per.xlsx',Ridge_pxFererl2_Fi_per);
xlswrite('Ridge_pxFererl2_Fi_el.xlsx',Ridge_pxFererl2_Fi_el);

