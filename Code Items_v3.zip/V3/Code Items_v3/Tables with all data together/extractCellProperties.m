function[propertiesXylem,propertiesFiber,propertiesPhloem,propertiesParynchema]=extractCellProperties(sourceFolder)
images =dir(fullfile(sourceFolder,'*.png'));
numFiles = length(images); %how many images in the folder

%start with a row of zeros to build tables
[propertiesXylem, propertiesFiber, propertiesPhloem, propertiesParynchema] = deal(zeros(4,1)');

%loop over images
%splitExport splits the images into binary images - white objects on black background
%these can be viewed as connected components of pixels whose properties can
%be extracted (area, perimeter, ellipticity)
%For each genotype, we have 6 images and 4 cell types
%splitExport returns, one image at a time, all the properties for all the
%different cell types for that image.
%the below loops over the images and stacks in a table the properties for
%all images for a specific genotype
for k = length(images):-1:1
[Xylem_Table_Num, Fiber_Table_Num,Phloem_Table_Num, Parynchema_Table_Num]=splitExport(images(k).name,sourceFolder);
    propertiesXylem=vertcat(propertiesXylem, Xylem_Table_Num);
    propertiesFiber=vertcat(propertiesFiber, Fiber_Table_Num);
    propertiesPhloem=vertcat(propertiesPhloem, Phloem_Table_Num);
    propertiesParynchema=vertcat(propertiesParynchema, Parynchema_Table_Num);
end

%remove zeros and convert pixels to microns
[propertiesXylem, propertiesFiber, propertiesPhloem, propertiesParynchema]=convert2Microns(propertiesXylem, propertiesFiber, propertiesPhloem, propertiesParynchema);
