function[cellType_Xy,cellType_Fi,cellType_Ph]=assignCellTypesStems(propertiesXylem,propertiesFiber,propertiesPhloem)
cellTypes={'Xylem' 'Xylem Parynchema' 'Phloem'};
cellType_Xy=repmat(cellTypes(1),size(propertiesXylem(:,1)),1);
cellType_Fi=repmat(cellTypes(2),size(propertiesFiber(:,1)),1);
cellType_Ph=repmat(cellTypes(3),size(propertiesPhloem(:,1)),1);
