function[Species_Xy,Species_Ph,Species_Pa]=assignSpeciesNoFiber(propertiesXylem,propertiesPhloem,propertiesParynchema,speciesName)

Species_Xy=repmat(speciesName,size(propertiesXylem(:,1)),1);
Species_Ph=repmat(speciesName,size(propertiesPhloem(:,1)),1);
Species_Pa=repmat(speciesName,size(propertiesParynchema(:,1)),1);