function [NumberPropertiesTable]=NumberProperties(cc) %input connected components, receive their properties


celldata = regionprops(cc, 'Area','MajorAxisLength','MinorAxisLength', 'Eccentricity', 'Perimeter'); %properties of connected components
cell_number=cc.NumObjects;
cell_areas=[celldata.Area]; %each element is a scalar=actual number of pixels in the region

lambda1=[celldata.MajorAxisLength];
lambda2=[celldata.MinorAxisLength];
ratio=lambda2./lambda1; %create ratio column
cell_perimeter=[celldata.Perimeter];

%the below two lines are not necessary as the entry 'typeofcellarray' was
%originally needed for the code but later became obsolete. Currently, it's
%just an easy way to help the code along without making a drastic number of
%changes
typeofcellarray = zeros(cell_number, 1);


    
NumberPropertiesTable(:, 1)= typeofcellarray';
NumberPropertiesTable(:, 2) = cell_areas';
NumberPropertiesTable(:, 3) = ratio';
NumberPropertiesTable(:, 4) = cell_perimeter';
NumberPropertiesTable;


