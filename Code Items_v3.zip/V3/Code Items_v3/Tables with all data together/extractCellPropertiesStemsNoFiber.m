function[propertiesXylem,propertiesPhloem]=extractCellPropertiesStemsNoFiber(sourceFolder)
%sourceWT = 'C:\Users\NBuser\Documents\MATLAB\Images\WT';
images =dir(fullfile(sourceFolder,'*.png'));
numFiles = length(images); %how many images in the folder

%start with a row of zeros to build tables
[propertiesXylem, propertiesPhloem] = deal(zeros(4,1)');

%loop over images
for k = length(images):-1:1
[Xylem_Table_Num, Phloem_Table_Num]=splitExportStemsNoFiber(images(k).name,sourceFolder);
    propertiesXylem=vertcat(propertiesXylem, Xylem_Table_Num);
    propertiesPhloem=vertcat(propertiesPhloem, Phloem_Table_Num);
end

%remove zeros and convert pixels to microns
[propertiesXylem, propertiesPhloem]=convert2MicronsStemsNoFiber(propertiesXylem, propertiesPhloem);

%remove outliers
%first for WT - xylem, fiber, phloem, parynchema
%numStdDev_WT=[3 1.6 3 3];
%[propertiesXylem,propertiesFiber,propertiesPhloem,propertiesParynchema]=remOutliersGenotype(numStdDev,propertiesXylem,propertiesFiber,propertiesPhloem,propertiesParynchema);
