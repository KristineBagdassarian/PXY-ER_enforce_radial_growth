%data is taken from file 'er-pxy family compare2.xls', hyp diamter table
WT_diam=[1.4 1.23 1.49 1.27 1.33 1.54 1.53 1.28 1.26 1.51 1.07 1.15 1.33 1.49 1.19];
pxy_diam=[1.37 1.42 1.1 1.29 1.06 1.1 1.44 1.22 1.23 0.98 1.45 1.33 1.22 1.35 0.97 1.28 1.45 1.02];
er_diam=[1.4 1.42 1.19 1.31 1.24 1.18 1.28 1.35 0.85 1.16 1.21 1.43 0.76 1.25 1.47 1.61 1.12 1.7];
pxyer_diam=[0.99 1.02 0.79 0.86 0.76 0.63 0.93 1 0.86 1.22 0.95 1.63 1.18 1.12 1.12 1.05];
ererl1erl2_diam=[0.67 1 0.61 0.82 0.94 0.92 0.6 0.74 0.58 0.77 0.95 0.69 0.82 1.17 0.92 1.1 0.94 0.88 0.91 1.11 0.76];
pxypxl1pxl2_diam=[1.4 1.3 0.95 1.01 1.16 0.96 1.15 1.03 1.2 1.14 1.37 1.03 1.27 0.99 1.22 0.81 1.35];
erpxypxl1pxl2_diam=[0.84 1.43 0.87 0.78 1.17 1.07 0.75 1.14 0.88 0.99 0.73 0.89 1.04 0.71 0.83 1.39];

%test if the two means are significantly different; One way ANOVA is a hypothesis test, used to test 
%the equality of three of more population means simultaneously using variance.
%We first test the normality assumption using the Lilliefors test at 5%
%significance and find out that it holds for all datasets, i.e. we are able
%to apply one-way (unbalanced) anova (unbalanced because the size of the
%vectors in the data is different for each group)
WT_test=lillietest(WT_diam); 
pxy_test=lillietest(pxy_diam); 
er_test=lillietest(er_diam);
pxyer_test=lillietest(pxyer_diam);
ererl1erl2_test=lillietest(ererl1erl2_diam);
pxypxl1pxl2_test=lillietest(pxypxl1pxl2_diam);
erpxypxl1pxl2_test=lillietest(erpxypxl1pxl2_diam);

%we put everything in the same vector
Diameters_all = [WT_diam'; pxy_diam'; er_diam'; pxyer_diam'; ererl1erl2_diam'; pxypxl1pxl2_diam'; erpxypxl1pxl2_diam'];

%need to sort them by group (take the size of each of the above and put that number of species names in the below )

GenoTypes={'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT' 'WT'...
    'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' 'pxy*' ...
    'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*' 'er*'...
    'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*' 'pxyer*'...
    'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*'  'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*'  'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*' 'ererl1erl2*'...
    'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*' 'pxypxl1pxl2*'...
    'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*' 'erpxypxl1pxl2*'};

[p,tbl,stats]=anova1(Diameters_all,GenoTypes)
figure
boxplot(Diameters_all, GenoTypes)
title('Hypocotyl diameter across genotypes')
ylabel('Diameter (mm)')
ylim([0 max(Diameters_all(:))])
figure
[c,~,~,gnames] = multcompare(stats);
%The first two columns show the pair of groups that are compared. 
%The fourth column shows the difference between the estimated group means. 
%The third and fifth columns show the lower and upper limits for the 95% confidence intervals 
%of the true difference of means. 
%The sixth column shows the p-value for a hypothesis 
%that the true difference of means for the corresponding groups is equal to zero.
comparison_table=[gnames(c(:,1)), gnames(c(:,2)), num2cell(c(:,3:6))];
row_one={'Group1' 'Group2' 'LowerLimitOf_95_CI' 'DiffBwnMeans' 'UpperLimitOf_95_CI' 'pvalue'};
Tukey_table=table(gnames(c(:,1)), gnames(c(:,2)),c(:,3), c(:,4), c(:,5),c(:,6));
Tukey_table.Properties.VariableNames = row_one;

%create Excel files for each species and cell types
filename_Tukey_table='Tukey_table_diam.xlsx';
writetable(Tukey_table, filename_Tukey_table);