%this programme extracts the properties of coloured cells from images
%the images are of cross-sections of plant stems; Each image has 
%a number of cell types manually selected and coloured. Each selected cell type
%uses a colour which is the same for all images, through all the different genotypes.
%The properties of the cells are assessed in the following way. The images are
%accessed from the folder by the programme. The images are then split into
%multiple binary images according to cell types. The cells in each image
%are then white objects on black background whose properties can be
%measured as the properties of white connected components. The programme
%below does this and then converts the pixel data into micros using a
%spatial factor which is separately calculated from the images using known
%size data and callibration ruler. The code produces files with each row
%containing data for a specific cell type for a specific plant. So in the
%file, the first row would contain all of the data for plant 1 of a
%particular genotype, row 2 would contain the data for plant 2 of the same
%plant and so on. This data will then be transformed to be assesed in R.


%For pxFererl1 stems


%calculate spatial and length factors for conversion from pixels to microns
SpatialFactor_Area=[10/36]*[10/36];
SpatialFactor_Length=[10/36];

%access the folder with pxFererl1 images
sourcepxFererl1 = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxFererl1';
imagespxFererl1 =dir(fullfile(sourcepxFererl1,'*.png'));
numFiles = length(imagespxFererl1); %how many images in the folder

%create an excell spreadsheet with the areas of each individual pxFererl1
%plant's cells in a row (e.g. row 1 contains the areas of pxFererl11)
for k = length(imagespxFererl1):-1:1
[Xylem_Table_Num_pxFererl1, Fiber_Table_Num_pxFererl1,Phloem_Table_Num_pxFererl1]=splitExportStems(imagespxFererl1(k).name,sourcepxFererl1);
    %select the rows in order for area
    my_cell = sprintf( 'A%s',num2str(k) );
    %create rows with area data for xylem(unedited)
    Xylem_Table_Num_pxFererl1(:,2)=Xylem_Table_Num_pxFererl1(:,2)*SpatialFactor_Area;
    xlswrite('Xylem_allpxFererl1_st.xlsx',Xylem_Table_Num_pxFererl1(:,2)',1,my_cell);
    %create rows with area data for fiber(unedited)
    Fiber_Table_Num_pxFererl1(:,2)=Fiber_Table_Num_pxFererl1(:,2)*SpatialFactor_Area;
    xlswrite('Fiber_allpxFererl1_st.xlsx',Fiber_Table_Num_pxFererl1(:,2)',1,my_cell);
    %create rows with area data for phloem(unedited)
    Phloem_Table_Num_pxFererl1(:,2)=Phloem_Table_Num_pxFererl1(:,2)*SpatialFactor_Area;
    xlswrite('Phloem_allpxFererl1_st.xlsx',Phloem_Table_Num_pxFererl1(:,2)',1,my_cell);
    
    %select the rows in order for perimeter
     
    Xylem_Table_Num_pxFererl1(:,4)=Xylem_Table_Num_pxFererl1(:,4)*SpatialFactor_Length;
    xlswrite('Xylem_allpxFererl1_per_st.xlsx',Xylem_Table_Num_pxFererl1(:,4)',1,my_cell);
    %create rows with perimeter data for fiber(unedited)
    Fiber_Table_Num_pxFererl1(:,4)=Fiber_Table_Num_pxFererl1(:,4)*SpatialFactor_Length;
    xlswrite('Fiber_allpxFererl1_per_st.xlsx',Fiber_Table_Num_pxFererl1(:,4)',1,my_cell);
    %create rows with perimeter data for phloem(unedited)
    Phloem_Table_Num_pxFererl1(:,4)=Phloem_Table_Num_pxFererl1(:,4)*SpatialFactor_Length;
    xlswrite('Phloem_allpxFererl1_per_st.xlsx',Phloem_Table_Num_pxFererl1(:,4)',1,my_cell);
     
    %select the rows in order for ellipticity
    
    Xylem_Table_Num_pxFererl1(:,3)=Xylem_Table_Num_pxFererl1(:,3);
    xlswrite('Xylem_allpxFererl1_el_st.xlsx',Xylem_Table_Num_pxFererl1(:,3)',1,my_cell);
    %create rows with ellipticity data for fiber(unedited)
    Fiber_Table_Num_pxFererl1(:,3)=Fiber_Table_Num_pxFererl1(:,3);
    xlswrite('Fiber_allpxFererl1_el_st.xlsx',Fiber_Table_Num_pxFererl1(:,3)',1,my_cell);
    %create rows with ellipticity data for phloem(unedited)
    Phloem_Table_Num_pxFererl1(:,3)=Phloem_Table_Num_pxFererl1(:,3);
    xlswrite('Phloem_allpxFererl1_el_st.xlsx',Phloem_Table_Num_pxFererl1(:,3)',1,my_cell);
    
end

