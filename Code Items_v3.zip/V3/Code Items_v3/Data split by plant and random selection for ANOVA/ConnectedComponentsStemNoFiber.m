function [Ix_cc,Iph_cc]=ConnectedComponentsStemNoFiber(Ix,Iph)

Ix_cc = bwconncomp(Ix, 8);
Iph_cc = bwconncomp(Iph, 8);

