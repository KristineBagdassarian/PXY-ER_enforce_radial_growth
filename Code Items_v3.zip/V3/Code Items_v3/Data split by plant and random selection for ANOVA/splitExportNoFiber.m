function[Xylem_Table_Num_WT, Phloem_Table_Num_WT, Parynchema_Table_Num_WT]=splitExportNoFiber(baseFileName,source)
%this function takes the 'name' for a source and the base name for an image
%reads the image and returns table of properties for that image

%for k = length(imagesWT):-1:1
   % baseFileName = imagesWT(k).name; %basic filename (the name before the '.png')
    fullFileName = fullfile(source, baseFileName); %combine for every filename
    imageRead= imread(fullFileName); %read each image
    [Ix,Iph,Ipa]=imagesNewNoFiber(imageRead); %separate the cell images for each
     %for the table of properties
    [Ix_cc,Iph_cc,Ipa_cc]=ConnectedComponentsNoFiber(Ix,Iph,Ipa); %connected components for each cell type
    Xylem_Table_Num_WT=NumberProperties(Ix_cc);
    Phloem_Table_Num_WT=NumberProperties(Iph_cc);
    Parynchema_Table_Num_WT=NumberProperties(Ipa_cc);
 