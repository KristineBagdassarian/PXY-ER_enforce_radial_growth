function[Xylem_Table_Num_WT, Fiber_Table_Num_WT,Phloem_Table_Num_WT, Parynchema_Table_Num_WT]=splitExport(baseFileName,source)
%this function takes the 'name' for a source and the base name for an image
%reads the image and returns table of properties for that image
  
    fullFileName = fullfile(source, baseFileName); %combine for every filename
    imageRead= imread(fullFileName); %read each image
    [Ix,Ip,Iph,Ipa]=imagesNew(imageRead); %separate the cell images for each
    %for the table of properties
    [Ix_cc,Ip_cc,Iph_cc,Ipa_cc]=ConnectedComponents(Ix,Ip,Iph,Ipa); %connected components for each cell type
    Xylem_Table_Num_WT=NumberProperties(Ix_cc);
    Fiber_Table_Num_WT=NumberProperties(Ip_cc);
    Phloem_Table_Num_WT=NumberProperties(Iph_cc);
    Parynchema_Table_Num_WT=NumberProperties(Ipa_cc);
   