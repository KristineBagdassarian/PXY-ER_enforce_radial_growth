%this function takes a file name and a number n and returns a matrix of
%data with equal length rows
%it imports a file with the name baseFileName, removes the NaN's from each
%row and every data point smaller than 1, then takes random sample of n
%frome each row, stacks up the new rows of random take and returns that
%matrix
function[importFile_Mat]=RandomSelect(baseFileName,n)
importFile=xlsread(baseFileName);
%importFile
importFile_Mat=zeros(1,n);
for i=1:6
row=importFile(i,:);%take the first row from the imported file
row=(row(~isnan(row))); %keep what is not NaN
row = row(row >=1); %keep anything >=1
row=datasample(row, n, 'Replace',false);
%row
 importFile_Mat=vertcat(importFile_Mat,row);
end
importFile_Mat(1,:)=[];

