%the function separates each images into several images based on the
%colours of the objects(cells)
function [Ix,Ip,Iph,Ipa]=imagesNew(I)

clc;
[x,y,numberofcolours]=size(I);

%create black images corresponding to each cell type
[Ix,Ip,Iph,Ipa] = deal(0*I);

for i=1:x
    for j=1:y
        if ((I(i,j,1)==254)&&(I(i,j,2)==0)&&(I(i,j,3)==0)) %image for xylem
            Ix(i,j,1)=255;
            Ix(i,j,2)=255;
            Ix(i,j,3)=255;
        elseif ((I(i,j,1)==0)&&(I(i,j,2)==0)&&(I(i,j,3)==254)) %image for fibers
            Ip(i,j,1)=255;
            Ip(i,j,2)=255;
            Ip(i,j,3)=255;
        elseif ((I(i,j,1)==0)&&(I(i,j,2)==255)&&(I(i,j,3)==3))%image for phloem
            Iph(i,j,1)=255;
            Iph(i,j,2)=255;
            Iph(i,j,3)=255;
        elseif ((I(i,j,1)==255)&&(I(i,j,2)==255)&&(I(i,j,3)==0)) %image for parynchema
            Ipa(i,j,1)=255;
            Ipa(i,j,2)=255;
            Ipa(i,j,3)=255;
        end
    end
end


Ix=im2bw(Ix); %transform into binary image
Ix=bwareaopen(Ix,50);%clear noise
%figure
%imshow(Ix), title('Xylem', 'Color', 'k');


Ip=im2bw(Ip);
Ip=bwareaopen(Ip,20);
%figure
%imshow(Ip), title('Xylem Fibers', 'Color', 'k');

Iph=im2bw(Iph);
Iph=bwareaopen(Iph,10);
%figure
%imshow(Iph), title('Phloem', 'Color', 'k');

Ipa=im2bw(Ipa);
Ipa=bwareaopen(Ipa,50);
%figure
%imshow(Ipa), title('Parenchyma', 'Color', 'k');




