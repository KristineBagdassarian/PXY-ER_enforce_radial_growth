function [Ix_cc,Ip_cc,Iph_cc,Ipa_cc]=ConnectedComponents(Ix,Ip,Iph,Ipa)

Ix_cc = bwconncomp(Ix, 8);
Ip_cc = bwconncomp(Ip, 4);
Iph_cc = bwconncomp(Iph, 8);
Ipa_cc = bwconncomp(Ipa, 8);
