%This programme takes the files containing the various cell data per plant per genotype
%(using these files' names) and applies a function to them to remove the
%NaN's and any items smaller than 1 (the noise), then selects a random
%sample of data with the same size n from each plant and genotype, creating
%a file that's exported
%number of parynchema cells samples
n=35;
Parynchema_all_plants_WT = 'Parynchema_allWT.xlsx';
Parynchema_all_plants_WT_per='Parynchema_allWT_per.xlsx';
Parynchema_all_plants_WT_el='Parynchema_allWT_el.xlsx';
[Ridge_WT_Pa,Ridge_WT_Pa_per, Ridge_WT_Pa_el]=RandomSelectAll(Parynchema_all_plants_WT,Parynchema_all_plants_WT_per,Parynchema_all_plants_WT_el, n);
xlswrite('Ridge_WT_Pa.xlsx',Ridge_WT_Pa);
xlswrite('Ridge_WT_Pa_per.xlsx',Ridge_WT_Pa_per);
xlswrite('Ridge_WT_Pa_el.xlsx',Ridge_WT_Pa_el);

%
Parynchema_all_plants_pxF = 'Parynchema_allpxF.xlsx';
Parynchema_all_plants_pxF_per='Parynchema_allpxF_per.xlsx';
Parynchema_all_plants_pxF_el='Parynchema_allpxF_el.xlsx';
[Ridge_pxF_Pa,Ridge_pxF_Pa_per, Ridge_pxF_Pa_el]=RandomSelectAll(Parynchema_all_plants_pxF,Parynchema_all_plants_pxF_per,Parynchema_all_plants_pxF_el, n);
xlswrite('Ridge_pxF_Pa.xlsx',Ridge_pxF_Pa);
xlswrite('Ridge_pxF_Pa_per.xlsx',Ridge_pxF_Pa_per);
xlswrite('Ridge_pxF_Pa_el.xlsx',Ridge_pxF_Pa_el);

Parynchema_all_plants_pxFer = 'Parynchema_allpxFer.xlsx';
Parynchema_all_plants_pxFer_per='Parynchema_allpxFer_per.xlsx';
Parynchema_all_plants_pxFer_el='Parynchema_allpxFer_el.xlsx';
[Ridge_pxFer_Pa,Ridge_pxFer_Pa_per, Ridge_pxFer_Pa_el]=RandomSelectAll(Parynchema_all_plants_pxFer,Parynchema_all_plants_pxFer_per,Parynchema_all_plants_pxFer_el, n);
xlswrite('Ridge_pxFer_Pa.xlsx',Ridge_pxFer_Pa);
xlswrite('Ridge_pxFer_Pa_per.xlsx',Ridge_pxFer_Pa_per);
xlswrite('Ridge_pxFer_Pa_el.xlsx',Ridge_pxFer_Pa_el);

Parynchema_all_plants_pxFererl1 = 'Parynchema_allpxFererl1.xlsx';
Parynchema_all_plants_pxFererl1_per='Parynchema_allpxFererl1_per.xlsx';
Parynchema_all_plants_pxFererl1_el='Parynchema_allpxFererl1_el.xlsx';
[Ridge_pxFererl1_Pa,Ridge_pxFererl1_Pa_per, Ridge_pxFererl1_Pa_el]=RandomSelectAll(Parynchema_all_plants_pxFererl1,Parynchema_all_plants_pxFererl1_per,Parynchema_all_plants_pxFererl1_el, n);
xlswrite('Ridge_pxFererl1_Pa.xlsx',Ridge_pxFererl1_Pa);
xlswrite('Ridge_pxFererl1_Pa_per.xlsx',Ridge_pxFererl1_Pa_per);
xlswrite('Ridge_pxFererl1_Pa_el.xlsx',Ridge_pxFererl1_Pa_el);

Parynchema_all_plants_pxFererl2 = 'Parynchema_allpxFererl2.xlsx';
Parynchema_all_plants_pxFererl2_per='Parynchema_allpxFererl2_per.xlsx';
Parynchema_all_plants_pxFererl2_el='Parynchema_allpxFererl2_el.xlsx';
[Ridge_pxFererl2_Pa,Ridge_pxFererl2_Pa_per, Ridge_pxFererl2_Pa_el]=RandomSelectAll(Parynchema_all_plants_pxFererl2,Parynchema_all_plants_pxFererl2_per,Parynchema_all_plants_pxFererl2_el, n);
xlswrite('Ridge_pxFererl2_Pa.xlsx',Ridge_pxFererl2_Pa);
xlswrite('Ridge_pxFererl2_Pa_per.xlsx',Ridge_pxFererl2_Pa_per);
xlswrite('Ridge_pxFererl2_Pa_el.xlsx',Ridge_pxFererl2_Pa_el);

Parynchema_all_plants_pxFerF = 'Parynchema_allpxFerF.xlsx';
Parynchema_all_plants_pxFerF_per='Parynchema_allpxFerF_per.xlsx';
Parynchema_all_plants_pxFerF_el='Parynchema_allpxFerF_el.xlsx';
[Ridge_pxFerF_Pa,Ridge_pxFerF_Pa_per, Ridge_pxFerF_Pa_el]=RandomSelectAll(Parynchema_all_plants_pxFerF,Parynchema_all_plants_pxFerF_per,Parynchema_all_plants_pxFerF_el, n);
xlswrite('Ridge_pxFerF_Pa.xlsx',Ridge_pxFerF_Pa);
xlswrite('Ridge_pxFerF_Pa_per.xlsx',Ridge_pxFerF_Pa_per);
xlswrite('Ridge_pxFerF_Pa_el.xlsx',Ridge_pxFerF_Pa_el);

