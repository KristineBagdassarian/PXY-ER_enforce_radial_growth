function [Ix_cc,Iph_cc,Ipa_cc]=ConnectedComponentsNoFiber(Ix,Iph,Ipa)

Ix_cc = bwconncomp(Ix, 8);
Iph_cc = bwconncomp(Iph, 8);
Ipa_cc = bwconncomp(Ipa, 8);
