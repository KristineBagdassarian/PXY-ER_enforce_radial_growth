%this function takes a file name and a number n and returns a matrix of
%data with equal length rows
%it imports a file with the name baseFileName, removes the NaN's from each
%row and every data point smaller than 1, then takes random sample of n
%frome each row, stacks up the new rows of random take and returns that
%matrix
function[importFile_Mat_area,importFile_Mat_per, importFile_Mat_el]=RandomSelectAll(baseFileName_area,baseFileName_per,baseFilename_el, n)
importFile_area=xlsread(baseFileName_area);
importFile_per=xlsread(baseFileName_per);
importFile_el=xlsread(baseFilename_el);
%importFile
importFile_Mat_area=zeros(1,n);
importFile_Mat_per=zeros(1,n);
importFile_Mat_el=zeros(1,n);
for i=1:6
row_area=importFile_area(i,:);%take the first row from the imported file
row_per=importFile_per(i,:);
row_el=importFile_el(i,:);
row_area=(row_area(~isnan(row_area))); %keep what is not NaN
row_per=(row_per(~isnan(row_per)));
row_el=(row_el(~isnan(row_el)));

row_area = row_area(row_area >=1); %keep anything >=1
row_per = row_per(row_per >0); %keep anything bigger than 0
row_el = row_el(row_el <1); %keep anything smaller than 1 (we just don't want it equal to 1)


%find out the length of the new row (should be same for all 3)
%randomly select n numbers between 1 and that length
%then extract the data from those positions

indx = datasample(1:length(row_area),n,'Replace',false);


row_area=row_area(indx);
row_per = row_per(indx);
row_el = row_el(indx);

%row
 importFile_Mat_area=vertcat(importFile_Mat_area,row_area);
 importFile_Mat_per=vertcat(importFile_Mat_per,row_per);
 importFile_Mat_el=vertcat(importFile_Mat_el,row_el);
end
importFile_Mat_area(1,:)=[];
importFile_Mat_per(1,:)=[];
importFile_Mat_el(1,:)=[];


