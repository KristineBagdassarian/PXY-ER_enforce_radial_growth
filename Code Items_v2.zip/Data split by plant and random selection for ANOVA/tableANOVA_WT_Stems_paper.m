%this programme extracts the properties of coloured cells from images
%the images are of cross-sections of plant stems; Each image has 
%a number of cell types manually selected and coloured. Each selected cell type
%uses a colour which is the same for all images, through all the different genotypes.
%The properties of the cells are assessed in the following way. The images are
%accessed from the folder by the programme. The images are then split into
%multiple binary images according to cell types. The cells in each image
%are then white objects on black background whose properties can be
%measured as the properties of white connected components. The programme
%below does this and then converts the pixel data into micros using a
%spatial factor which is separately calculated from the images using known
%size data and callibration ruler. The code produces files with each row
%containing data for a specific cell type for a specific plant. So in the
%file, the first row would contain all of the data for plant 1 of a
%particular genotype, row 2 would contain the data for plant 2 of the same
%plant and so on. This data will then be transformed to be assesed in R.


%For WT stems

%calculate spatial and length factors for conversion from pixels to microns
SpatialFactor_Area=[10/36]*[10/36];
SpatialFactor_Length=[10/36];

%access the folder with WT images
sourceWT = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\\WT';
imagesWT =dir(fullfile(sourceWT,'*.png'));
numFiles = length(imagesWT); %how many images in the folder

%create an excell spreadsheet with the areas of each individual WT
%plant's cells in a row (e.g. row 1 contains the areas of WT1)
for k = length(imagesWT):-1:1
[Xylem_Table_Num_WT, Fiber_Table_Num_WT,Phloem_Table_Num_WT]=splitExportStems(imagesWT(k).name,sourceWT);
    %select the rows in order for area
    my_cell = sprintf( 'A%s',num2str(k) );
    %create rows with area data for xylem(unedited)
    Xylem_Table_Num_WT(:,2)=Xylem_Table_Num_WT(:,2)*SpatialFactor_Area;
    xlswrite('Xylem_allWT_st.xlsx',Xylem_Table_Num_WT(:,2)',1,my_cell);
    %create rows with area data for fiber(unedited)
    Fiber_Table_Num_WT(:,2)=Fiber_Table_Num_WT(:,2)*SpatialFactor_Area;
    xlswrite('Fiber_allWT_st.xlsx',Fiber_Table_Num_WT(:,2)',1,my_cell);
    %create rows with area data for phloem(unedited)
    Phloem_Table_Num_WT(:,2)=Phloem_Table_Num_WT(:,2)*SpatialFactor_Area;
    xlswrite('Phloem_allWT_st.xlsx',Phloem_Table_Num_WT(:,2)',1,my_cell);
    
    %select the rows in order for perimeter
     
    Xylem_Table_Num_WT(:,4)=Xylem_Table_Num_WT(:,4)*SpatialFactor_Length;
    xlswrite('Xylem_allWT_per_st.xlsx',Xylem_Table_Num_WT(:,4)',1,my_cell);
    %create rows with perimeter data for fiber(unedited)
    Fiber_Table_Num_WT(:,4)=Fiber_Table_Num_WT(:,4)*SpatialFactor_Length;
    xlswrite('Fiber_allWT_per_st.xlsx',Fiber_Table_Num_WT(:,4)',1,my_cell);
    %create rows with perimeter data for phloem(unedited)
    Phloem_Table_Num_WT(:,4)=Phloem_Table_Num_WT(:,4)*SpatialFactor_Length;
    xlswrite('Phloem_allWT_per_st.xlsx',Phloem_Table_Num_WT(:,4)',1,my_cell);
     
    %select the rows in order for ellipticity
    
    Xylem_Table_Num_WT(:,3)=Xylem_Table_Num_WT(:,3);
    xlswrite('Xylem_allWT_el_st.xlsx',Xylem_Table_Num_WT(:,3)',1,my_cell);
    %create rows with ellipticity data for fiber(unedited)
    Fiber_Table_Num_WT(:,3)=Fiber_Table_Num_WT(:,3);
    xlswrite('Fiber_allWT_el_st.xlsx',Fiber_Table_Num_WT(:,3)',1,my_cell);
    %create rows with ellipticity data for phloem(unedited)
    Phloem_Table_Num_WT(:,3)=Phloem_Table_Num_WT(:,3);
    xlswrite('Phloem_allWT_el_st.xlsx',Phloem_Table_Num_WT(:,3)',1,my_cell);
    
end

