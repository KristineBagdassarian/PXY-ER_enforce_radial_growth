%This programme takes the files containing the various cell data per plant per genotype
%(using these files' names) and applies a function to them to remove the
%NaN's and any items smaller than 1 (the noise), then selects a random
%sample of data with the same size n from each plant and genotype, creating
%a file that's exported
%number of cells sampled per plant for phloem cells
n=20;
%name of the file to be read
Phloem_all_plants_WT = 'Phloem_allWT.xlsx';
Phloem_all_plants_WT_per='Phloem_allWT_per.xlsx';
Phloem_all_plants_WT_el='Phloem_allWT_el.xlsx';
[Ridge_WT_Ph,Ridge_WT_Ph_per, Ridge_WT_Ph_el]=RandomSelectAll(Phloem_all_plants_WT,Phloem_all_plants_WT_per,Phloem_all_plants_WT_el, n);
xlswrite('Ridge_WT_Ph.xlsx',Ridge_WT_Ph);
xlswrite('Ridge_WT_Ph_per.xlsx',Ridge_WT_Ph_per);
xlswrite('Ridge_WT_Ph_el.xlsx',Ridge_WT_Ph_el);

%
Phloem_all_plants_pxF = 'Phloem_allpxF.xlsx';
Phloem_all_plants_pxF_per='Phloem_allpxF_per.xlsx';
Phloem_all_plants_pxF_el='Phloem_allpxF_el.xlsx';
[Ridge_pxF_Ph,Ridge_pxF_Ph_per, Ridge_pxF_Ph_el]=RandomSelectAll(Phloem_all_plants_pxF,Phloem_all_plants_pxF_per,Phloem_all_plants_pxF_el, n);
xlswrite('Ridge_pxF_Ph.xlsx',Ridge_pxF_Ph);
xlswrite('Ridge_pxF_Ph_per.xlsx',Ridge_pxF_Ph_per);
xlswrite('Ridge_pxF_Ph_el.xlsx',Ridge_pxF_Ph_el);

Phloem_all_plants_pxFer = 'Phloem_allpxFer.xlsx';
Phloem_all_plants_pxFer_per='Phloem_allpxFer_per.xlsx';
Phloem_all_plants_pxFer_el='Phloem_allpxFer_el.xlsx';
[Ridge_pxFer_Ph,Ridge_pxFer_Ph_per, Ridge_pxFer_Ph_el]=RandomSelectAll(Phloem_all_plants_pxFer,Phloem_all_plants_pxFer_per,Phloem_all_plants_pxFer_el, n);
xlswrite('Ridge_pxFer_Ph.xlsx',Ridge_pxFer_Ph);
xlswrite('Ridge_pxFer_Ph_per.xlsx',Ridge_pxFer_Ph_per);
xlswrite('Ridge_pxFer_Ph_el.xlsx',Ridge_pxFer_Ph_el);

Phloem_all_plants_pxFererl1 = 'Phloem_allpxFererl1.xlsx';
Phloem_all_plants_pxFererl1_per='Phloem_allpxFererl1_per.xlsx';
Phloem_all_plants_pxFererl1_el='Phloem_allpxFererl1_el.xlsx';
[Ridge_pxFererl1_Ph,Ridge_pxFererl1_Ph_per, Ridge_pxFererl1_Ph_el]=RandomSelectAll(Phloem_all_plants_pxFererl1,Phloem_all_plants_pxFererl1_per,Phloem_all_plants_pxFererl1_el, n);
xlswrite('Ridge_pxFererl1_Ph.xlsx',Ridge_pxFererl1_Ph);
xlswrite('Ridge_pxFererl1_Ph_per.xlsx',Ridge_pxFererl1_Ph_per);
xlswrite('Ridge_pxFererl1_Ph_el.xlsx',Ridge_pxFererl1_Ph_el);

Phloem_all_plants_pxFererl2 = 'Phloem_allpxFererl2.xlsx';
Phloem_all_plants_pxFererl2_per='Phloem_allpxFererl2_per.xlsx';
Phloem_all_plants_pxFererl2_el='Phloem_allpxFererl2_el.xlsx';
[Ridge_pxFererl2_Ph,Ridge_pxFererl2_Ph_per, Ridge_pxFererl2_Ph_el]=RandomSelectAll(Phloem_all_plants_pxFererl2,Phloem_all_plants_pxFererl2_per,Phloem_all_plants_pxFererl2_el, n);
xlswrite('Ridge_pxFererl2_Ph.xlsx',Ridge_pxFererl2_Ph);
xlswrite('Ridge_pxFererl2_Ph_per.xlsx',Ridge_pxFererl2_Ph_per);
xlswrite('Ridge_pxFererl2_Ph_el.xlsx',Ridge_pxFererl2_Ph_el);

Phloem_all_plants_pxFerF = 'Phloem_allpxFerF.xlsx';
Phloem_all_plants_pxFerF_per='Phloem_allpxFerF_per.xlsx';
Phloem_all_plants_pxFerF_el='Phloem_allpxFerF_el.xlsx';
[Ridge_pxFerF_Ph,Ridge_pxFerF_Ph_per, Ridge_pxFerF_Ph_el]=RandomSelectAll(Phloem_all_plants_pxFerF,Phloem_all_plants_pxFerF_per,Phloem_all_plants_pxFerF_el, n);
xlswrite('Ridge_pxFerF_Ph.xlsx',Ridge_pxFerF_Ph);
xlswrite('Ridge_pxFerF_Ph_per.xlsx',Ridge_pxFerF_Ph_per);
xlswrite('Ridge_pxFerF_Ph_el.xlsx',Ridge_pxFerF_Ph_el);

