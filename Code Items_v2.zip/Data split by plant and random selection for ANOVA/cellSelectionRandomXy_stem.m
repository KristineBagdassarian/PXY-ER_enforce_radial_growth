%This programme takes the files containing the various cell data per plant per genotype
%(using these files' names) and applies a function to them to remove the
%NaN's and any items smaller than 1 (the noise), then selects a random
%sample of data with the same size n from each plant and genotype, creating
%a file that's exported
%number of xylem vessels samples per plant per genotype
n=12;

Xylem_all_plants_WT = 'Xylem_allWT_st.xlsx';
Xylem_all_plants_WT_per='Xylem_allWT_per_st.xlsx';
Xylem_all_plants_WT_el='Xylem_allWT_el_st.xlsx';
[Ridge_WT_Xy,Ridge_WT_Xy_per, Ridge_WT_Xy_el]=RandomSelectAll(Xylem_all_plants_WT,Xylem_all_plants_WT_per,Xylem_all_plants_WT_el, n);
xlswrite('Ridge_WT_Xy_st.xlsx',Ridge_WT_Xy);
xlswrite('Ridge_WT_Xy_per_st.xlsx',Ridge_WT_Xy_per);
xlswrite('Ridge_WT_Xy_el_st.xlsx',Ridge_WT_Xy_el);


Xylem_all_plants_pxF = 'Xylem_allpxF_st.xlsx';
Xylem_all_plants_pxF_per='Xylem_allpxF_per_st.xlsx';
Xylem_all_plants_pxF_el='Xylem_allpxF_el_st.xlsx';
[Ridge_pxF_Xy,Ridge_pxF_Xy_per, Ridge_pxF_Xy_el]=RandomSelectAll(Xylem_all_plants_pxF,Xylem_all_plants_pxF_per,Xylem_all_plants_pxF_el, n);
xlswrite('Ridge_pxF_Xy_st.xlsx',Ridge_pxF_Xy);
xlswrite('Ridge_pxF_Xy_per_st.xlsx',Ridge_pxF_Xy_per);
xlswrite('Ridge_pxF_Xy_el_st.xlsx',Ridge_pxF_Xy_el);

Xylem_all_plants_pxFer = 'Xylem_allpxFer_st.xlsx';
Xylem_all_plants_pxFer_per='Xylem_allpxFer_per_st.xlsx';
Xylem_all_plants_pxFer_el='Xylem_allpxFer_el_st.xlsx';
[Ridge_pxFer_Xy,Ridge_pxFer_Xy_per, Ridge_pxFer_Xy_el]=RandomSelectAll(Xylem_all_plants_pxFer,Xylem_all_plants_pxFer_per,Xylem_all_plants_pxFer_el, n);
xlswrite('Ridge_pxFer_Xy_st.xlsx',Ridge_pxFer_Xy);
xlswrite('Ridge_pxFer_Xy_per_st.xlsx',Ridge_pxFer_Xy_per);
xlswrite('Ridge_pxFer_Xy_el_st.xlsx',Ridge_pxFer_Xy_el);

Xylem_all_plants_pxFererl1 = 'Xylem_allpxFererl1_st.xlsx';
Xylem_all_plants_pxFererl1_per='Xylem_allpxFererl1_per_st.xlsx';
Xylem_all_plants_pxFererl1_el='Xylem_allpxFererl1_el_st.xlsx';
[Ridge_pxFererl1_Xy,Ridge_pxFererl1_Xy_per, Ridge_pxFererl1_Xy_el]=RandomSelectAll(Xylem_all_plants_pxFererl1,Xylem_all_plants_pxFererl1_per,Xylem_all_plants_pxFererl1_el, n);
xlswrite('Ridge_pxFererl1_Xy_st.xlsx',Ridge_pxFererl1_Xy);
xlswrite('Ridge_pxFererl1_Xy_per_st.xlsx',Ridge_pxFererl1_Xy_per);
xlswrite('Ridge_pxFererl1_Xy_el_st.xlsx',Ridge_pxFererl1_Xy_el);

Xylem_all_plants_pxFererl2 = 'Xylem_allpxFererl2_st.xlsx';
Xylem_all_plants_pxFererl2_per='Xylem_allpxFererl2_per_st.xlsx';
Xylem_all_plants_pxFererl2_el='Xylem_allpxFererl2_el_st.xlsx';
[Ridge_pxFererl2_Xy,Ridge_pxFererl2_Xy_per, Ridge_pxFererl2_Xy_el]=RandomSelectAll(Xylem_all_plants_pxFererl2,Xylem_all_plants_pxFererl2_per,Xylem_all_plants_pxFererl2_el, n);
xlswrite('Ridge_pxFererl2_Xy_st.xlsx',Ridge_pxFererl2_Xy);
xlswrite('Ridge_pxFererl2_Xy_per_st.xlsx',Ridge_pxFererl2_Xy_per);
xlswrite('Ridge_pxFererl2_Xy_el_st.xlsx',Ridge_pxFererl2_Xy_el);

Xylem_all_plants_pxFerF = 'Xylem_allpxFerF_st.xlsx';
Xylem_all_plants_pxFerF_per='Xylem_allpxFerF_per_st.xlsx';
Xylem_all_plants_pxFerF_el='Xylem_allpxFerF_el_st.xlsx';
[Ridge_pxFerF_Xy,Ridge_pxFerF_Xy_per, Ridge_pxFerF_Xy_el]=RandomSelectAll(Xylem_all_plants_pxFerF,Xylem_all_plants_pxFerF_per,Xylem_all_plants_pxFerF_el, n);
xlswrite('Ridge_pxFerF_Xy_st.xlsx',Ridge_pxFerF_Xy);
xlswrite('Ridge_pxFerF_Xy_per_st.xlsx',Ridge_pxFerF_Xy_per);
xlswrite('Ridge_pxFerF_Xy_el_st.xlsx',Ridge_pxFerF_Xy_el);

