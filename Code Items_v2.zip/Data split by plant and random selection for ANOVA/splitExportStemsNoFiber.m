function[Xylem_Table_Num_WT, Phloem_Table_Num_WT]=splitExportStemsNoFiber(baseFileName,source)
%this function takes the 'name' for a source and the base name for an image
%reads the image and returns table of properties for that image
TypeXylem=1000; TypePhloem=3000; 
    fullFileName = fullfile(source, baseFileName); %combine for every filename
    imageRead= imread(fullFileName); %read each image
    [Ix,Iph]=imagesNewStemsNoFiber(imageRead); %separate the cell images for each
    [Ix_cc,Iph_cc]=ConnectedComponentsStemNoFiber(Ix,Iph); %connected components for each cell type
    Xylem_Table_Num_WT=NumberProperties(Ix_cc,TypeXylem);
    Phloem_Table_Num_WT=NumberProperties(Iph_cc,TypePhloem);
   