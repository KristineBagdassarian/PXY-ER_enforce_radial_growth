function[Species_Xy,Species_Ph]=assignSpeciesStemsNoFiber(propertiesXylem,propertiesPhloem,speciesName)

Species_Xy=repmat(speciesName,size(propertiesXylem(:,1)),1);
Species_Ph=repmat(speciesName,size(propertiesPhloem(:,1)),1);
