%the code reads images from a folder, then extracts the properties of the
%differently coloured cells based on size and shape
%the extracted data is saved into excell tables

%In the below, WT corresponds to Wild Type


%access the folder with WT images
%apply algorithm to WT images 
%with number of standard deviations for outlier removal as below

sourceWT = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\WT';
[propertiesXylem_WT,propertiesFiber_WT,propertiesPhloem_WT]=extractCellPropertiesStems(sourceWT);

%repeat for other genotypes

sourcepxF = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxF';
[propertiesXylem_pxF,propertiesFiber_pxF,propertiesPhloem_pxF]=extractCellPropertiesStems(sourcepxF);

sourcepxFer = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxF er';
[propertiesXylem_pxFer,propertiesFiber_pxFer,propertiesPhloem_pxFer]=extractCellPropertiesStems(sourcepxFer);

sourcepxFererl1 = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxF er erl1';
[propertiesXylem_pxFererl1,propertiesFiber_pxFererl1,propertiesPhloem_pxFererl1]=extractCellPropertiesStems(sourcepxFererl1);

sourcepxFererl2 = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxF er erl2';
[propertiesXylem_pxFererl2,propertiesFiber_pxFererl2,propertiesPhloem_pxFererl2]=extractCellPropertiesStems(sourcepxFererl2);

%note that pxFerF has no distinguishable xylem parynchema; i.e. a new function
%needs to be designed
sourcepxFerF = 'C:\Users\NBuser\Documents\MATLAB\Images Paper - Stems\Coloured\Coloured\pxF erF';
[propertiesXylem_pxFerF,propertiesPhloem_pxFerF]=extractCellPropertiesStemsNoFiber(sourcepxFerF);


%names of different columns in future tables

CellProperties={'Species' 'CellType' 'CellArea' 'Ratio' 'Perimeter'};

%name species for each matrix
SpeciesWT='WT';
[Species_WT_Xy,Species_WT_Fi,Species_WT_Ph]=assignSpeciesStems(propertiesXylem_WT,propertiesFiber_WT,propertiesPhloem_WT,SpeciesWT);
SpeciespxF='pxF';
[Species_pxF_Xy,Species_pxF_Fi,Species_pxF_Ph]=assignSpeciesStems(propertiesXylem_pxF,propertiesFiber_pxF,propertiesPhloem_pxF,SpeciespxF);
SpeciespxFer='pxFer';
[Species_pxFer_Xy,Species_pxFer_Fi,Species_pxFer_Ph]=assignSpeciesStems(propertiesXylem_pxFer,propertiesFiber_pxFer,propertiesPhloem_pxFer,SpeciespxFer);
SpeciespxFererl1='pxFererl1';
[Species_pxFererl1_Xy,Species_pxFererl1_Fi,Species_pxFererl1_Ph]=assignSpeciesStems(propertiesXylem_pxFererl1,propertiesFiber_pxFererl1,propertiesPhloem_pxFererl1,SpeciespxFererl1);
SpeciespxFererl2='pxFererl2';
[Species_pxFererl2_Xy,Species_pxFererl2_Fi,Species_pxFererl2_Ph]=assignSpeciesStems(propertiesXylem_pxFererl2,propertiesFiber_pxFererl2,propertiesPhloem_pxFererl2,SpeciespxFererl2);

%pxFerF has no xylem parynchema
SpeciespxFerF='pxFerF';
[Species_pxFerF_Xy,Species_pxFerF_Ph]=assignSpeciesStemsNoFiber(propertiesXylem_pxFerF,propertiesPhloem_pxFerF,SpeciespxFerF);


%assign names to the cell types in WT
[cellType_WT_Xy,cellType_WT_Fi,cellType_WT_Ph]=assignCellTypesStems(propertiesXylem_WT,propertiesFiber_WT,propertiesPhloem_WT);

%assign names to the cell types in pxF
[cellType_pxF_Xy,cellType_pxF_Fi,cellType_pxF_Ph]=assignCellTypesStems(propertiesXylem_pxF,propertiesFiber_pxF,propertiesPhloem_pxF);

%assign names to the cell types in pxFer
[cellType_pxFer_Xy,cellType_pxFer_Fi,cellType_pxFer_Ph]=assignCellTypesStems(propertiesXylem_pxFer,propertiesFiber_pxFer,propertiesPhloem_pxFer);

%assign names to the cell types in pxFererl1
[cellType_pxFererl1_Xy,cellType_pxFererl1_Fi,cellType_pxFererl1_Ph]=assignCellTypesStems(propertiesXylem_pxFererl1,propertiesFiber_pxFererl1,propertiesPhloem_pxFererl1);

%assign names to the cell types in pxFererl2
[cellType_pxFererl2_Xy,cellType_pxFererl2_Fi,cellType_pxFererl2_Ph]=assignCellTypesStems(propertiesXylem_pxFererl2,propertiesFiber_pxFererl2,propertiesPhloem_pxFererl2);

%assign names to the cell types in pxFerF (it has no xylem parynchema)
[cellType_pxFerF_Xy,cellType_pxFerF_Ph]=assignCellTypesStemsNoFiber(propertiesXylem_pxFerF,propertiesPhloem_pxFerF);


%create tables with the properties
%add variable names for each
%For WT
WT_Table_Xy = table(Species_WT_Xy, cellType_WT_Xy, propertiesXylem_WT(:,2),propertiesXylem_WT(:,3),propertiesXylem_WT(:,4)); %the name of the rows come after 'RowNames'
WT_Table_Xy.Properties.VariableNames = CellProperties;

WT_Table_Fi = table(Species_WT_Fi, cellType_WT_Fi, propertiesFiber_WT(:,2),propertiesFiber_WT(:,3),propertiesFiber_WT(:,4)); %the name of the rows come after 'RowNames'
WT_Table_Fi.Properties.VariableNames = CellProperties;

WT_Table_Ph = table(Species_WT_Ph, cellType_WT_Ph, propertiesPhloem_WT(:,2),propertiesPhloem_WT(:,3),propertiesPhloem_WT(:,4)); %the name of the rows come after 'RowNames'
WT_Table_Ph.Properties.VariableNames = CellProperties;

%For pxF
pxF_Table_Xy=table(Species_pxF_Xy, cellType_pxF_Xy, propertiesXylem_pxF(:,2),propertiesXylem_pxF(:,3),propertiesXylem_pxF(:,4)); %the name of the rows come after 'RowNames'
pxF_Table_Xy.Properties.VariableNames = CellProperties;

pxF_Table_Fi = table(Species_pxF_Fi, cellType_pxF_Fi, propertiesFiber_pxF(:,2),propertiesFiber_pxF(:,3),propertiesFiber_pxF(:,4)); %the name of the rows come after 'RowNames'
pxF_Table_Fi.Properties.VariableNames = CellProperties;

pxF_Table_Ph = table(Species_pxF_Ph, cellType_pxF_Ph, propertiesPhloem_pxF(:,2),propertiesPhloem_pxF(:,3),propertiesPhloem_pxF(:,4)); %the name of the rows come after 'RowNames'
pxF_Table_Ph.Properties.VariableNames = CellProperties;


%For pxFer
pxFer_Table_Xy=table(Species_pxFer_Xy, cellType_pxFer_Xy, propertiesXylem_pxFer(:,2),propertiesXylem_pxFer(:,3),propertiesXylem_pxFer(:,4)); %the name of the rows come after 'RowNames'
pxFer_Table_Xy.Properties.VariableNames = CellProperties;

pxFer_Table_Fi = table(Species_pxFer_Fi, cellType_pxFer_Fi, propertiesFiber_pxFer(:,2),propertiesFiber_pxFer(:,3),propertiesFiber_pxFer(:,4)); %the name of the rows come after 'RowNames'
pxFer_Table_Fi.Properties.VariableNames = CellProperties;

pxFer_Table_Ph = table(Species_pxFer_Ph, cellType_pxFer_Ph, propertiesPhloem_pxFer(:,2),propertiesPhloem_pxFer(:,3),propertiesPhloem_pxFer(:,4)); %the name of the rows come after 'RowNames'
pxFer_Table_Ph.Properties.VariableNames = CellProperties;


%For pxFererl1
pxFererl1_Table_Xy=table(Species_pxFererl1_Xy, cellType_pxFererl1_Xy, propertiesXylem_pxFererl1(:,2),propertiesXylem_pxFererl1(:,3),propertiesXylem_pxFererl1(:,4)); %the name of the rows come after 'RowNames'
pxFererl1_Table_Xy.Properties.VariableNames = CellProperties;

pxFererl1_Table_Fi = table(Species_pxFererl1_Fi, cellType_pxFererl1_Fi, propertiesFiber_pxFererl1(:,2),propertiesFiber_pxFererl1(:,3),propertiesFiber_pxFererl1(:,4)); %the name of the rows come after 'RowNames'
pxFererl1_Table_Fi.Properties.VariableNames = CellProperties;

pxFererl1_Table_Ph = table(Species_pxFererl1_Ph, cellType_pxFererl1_Ph, propertiesPhloem_pxFererl1(:,2),propertiesPhloem_pxFererl1(:,3),propertiesPhloem_pxFererl1(:,4)); %the name of the rows come after 'RowNames'
pxFererl1_Table_Ph.Properties.VariableNames = CellProperties;

%For pxFererl2
pxFererl2_Table_Xy=table(Species_pxFererl2_Xy, cellType_pxFererl2_Xy, propertiesXylem_pxFererl2(:,2),propertiesXylem_pxFererl2(:,3),propertiesXylem_pxFererl2(:,4)); %the name of the rows come after 'RowNames'
pxFererl2_Table_Xy.Properties.VariableNames = CellProperties;

pxFererl2_Table_Fi = table(Species_pxFererl2_Fi, cellType_pxFererl2_Fi, propertiesFiber_pxFererl2(:,2),propertiesFiber_pxFererl2(:,3),propertiesFiber_pxFererl2(:,4)); %the name of the rows come after 'RowNames'
pxFererl2_Table_Fi.Properties.VariableNames = CellProperties;

pxFererl2_Table_Ph = table(Species_pxFererl2_Ph, cellType_pxFererl2_Ph, propertiesPhloem_pxFererl2(:,2),propertiesPhloem_pxFererl2(:,3),propertiesPhloem_pxFererl2(:,4)); %the name of the rows come after 'RowNames'
pxFererl2_Table_Ph.Properties.VariableNames = CellProperties;


%For pxFerF

pxFerF_Table_Xy=table(Species_pxFerF_Xy, cellType_pxFerF_Xy, propertiesXylem_pxFerF(:,2),propertiesXylem_pxFerF(:,3),propertiesXylem_pxFerF(:,4)); %the name of the rows come after 'RowNames'
pxFerF_Table_Xy.Properties.VariableNames = CellProperties;

pxFerF_Table_Ph = table(Species_pxFerF_Ph, cellType_pxFerF_Ph, propertiesPhloem_pxFerF(:,2),propertiesPhloem_pxFerF(:,3),propertiesPhloem_pxFerF(:,4)); %the name of the rows come after 'RowNames'
pxFerF_Table_Ph.Properties.VariableNames = CellProperties;


%create Excel files for each species and cell types

%WT
filename_WT_Xy='WT_Table_Xy_file_Stem.xlsx';
writetable(WT_Table_Xy, filename_WT_Xy);

filename_WT_Fi='WT_Table_Fi_file_Stem.xlsx';
writetable(WT_Table_Fi, filename_WT_Fi);

filename_WT_Ph='WT_Table_Ph_file_Stem.xlsx';
writetable(WT_Table_Ph, filename_WT_Ph);

%pxF
filename_pxF_Xy='pxF_Table_Xy_file_Stem.xlsx';
writetable(pxF_Table_Xy, filename_pxF_Xy);

filename_pxF_Fi='pxF_Table_Fi_file_Stem.xlsx';
writetable(pxF_Table_Fi, filename_pxF_Fi);

filename_pxF_Ph='pxF_Table_Ph_file_Stem.xlsx';
writetable(pxF_Table_Ph, filename_pxF_Ph);


%pxFer
filename_pxFer_Xy='pxFer_Table_Xy_file_Stem.xlsx';
writetable(pxFer_Table_Xy, filename_pxFer_Xy);

filename_pxFer_Fi='pxFer_Table_Fi_file_Stem.xlsx';
writetable(pxFer_Table_Fi, filename_pxFer_Fi);

filename_pxFer_Ph='pxFer_Table_Ph_file_Stem.xlsx';
writetable(pxFer_Table_Ph, filename_pxFer_Ph);


%pxFererl1

filename_pxFererl1_Xy='pxFererl1_Table_Xy_file_Stem.xlsx';
writetable(pxFererl1_Table_Xy, filename_pxFererl1_Xy);

filename_pxFererl1_Fi='pxFererl1_Table_Fi_file_Stem.xlsx';
writetable(pxFererl1_Table_Fi, filename_pxFererl1_Fi);

filename_pxFererl1_Ph='pxFererl1_Table_Ph_file_Stem.xlsx';
writetable(pxFererl1_Table_Ph, filename_pxFererl1_Ph);

%pxFererl2

filename_pxFererl2_Xy='pxFererl2_Table_Xy_file_Stem.xlsx';
writetable(pxFererl2_Table_Xy, filename_pxFererl2_Xy);

filename_pxFererl2_Fi='pxFererl2_Table_Fi_file_Stem.xlsx';
writetable(pxFererl2_Table_Fi, filename_pxFererl2_Fi);

filename_pxFererl2_Ph='pxFererl2_Table_Ph_file_Stem.xlsx';
writetable(pxFererl2_Table_Ph, filename_pxFererl2_Ph);

%pxFerF

filename_pxFerF_Xy='pxFerF_Table_Xy_file_Stem.xlsx';
writetable(pxFerF_Table_Xy, filename_pxFerF_Xy);

filename_pxFerF_Ph='pxFerF_Table_Ph_file_Stem.xlsx';
writetable(pxFerF_Table_Ph, filename_pxFerF_Ph);
