function[Species_Xy,Species_Fi,Species_Ph,Species_Pa]=assignSpecies(propertiesXylem,propertiesFiber,propertiesPhloem,propertiesParynchema,speciesName)

Species_Xy=repmat(speciesName,size(propertiesXylem(:,1)),1);
Species_Fi=repmat(speciesName,size(propertiesFiber(:,1)),1);
Species_Ph=repmat(speciesName,size(propertiesPhloem(:,1)),1);
Species_Pa=repmat(speciesName,size(propertiesParynchema(:,1)),1);