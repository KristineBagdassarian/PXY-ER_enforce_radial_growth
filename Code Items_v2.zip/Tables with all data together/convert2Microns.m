function[propertiesXylem, propertiesFiber, propertiesPhloem, propertiesParynchema]=convert2Microns(propertiesXylem, propertiesFiber, propertiesPhloem, propertiesParynchema)
%the function takes the table of properties of different cell types
%removes first row of zeros
%then uses callibration factors for area and length to convert pixels to
%microns

%calculate spatial and length factors for conversion from pixels to microns
SpatialFactor_Area=[10/33]*[10/33];
SpatialFactor_Length=[10/33];

%remove first row of zeros
propertiesXylem(1,:)=[];
propertiesFiber(1,:)=[];
propertiesPhloem(1,:)=[];
propertiesParynchema(1,:)=[];
%callibrate pixels to microns
propertiesXylem(:,2)=propertiesXylem(:,2)*SpatialFactor_Area;
propertiesXylem(:,4)=propertiesXylem(:,4)*SpatialFactor_Length;

propertiesFiber(:,2)=propertiesFiber(:,2)*SpatialFactor_Area;
propertiesFiber(:,4)=propertiesFiber(:,4)*SpatialFactor_Length;

propertiesPhloem(:,2)=propertiesPhloem(:,2)*SpatialFactor_Area;
propertiesPhloem(:,4)=propertiesPhloem(:,4)*SpatialFactor_Length;

propertiesParynchema(:,2)=propertiesParynchema(:,2)*SpatialFactor_Area;
propertiesParynchema(:,4)=propertiesParynchema(:,4)*SpatialFactor_Length;